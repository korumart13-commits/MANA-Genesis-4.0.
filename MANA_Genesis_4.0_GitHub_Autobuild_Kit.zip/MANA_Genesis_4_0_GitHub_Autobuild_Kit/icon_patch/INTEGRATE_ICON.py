#!/usr/bin/env python3
"""Copy the supplied MANA launcher resources into an Android app module."""
from pathlib import Path
import shutil, sys, xml.etree.ElementTree as ET
if len(sys.argv) != 2:
    raise SystemExit('Usage: python3 INTEGRATE_ICON.py /path/to/MANA_OS_3_0_Android_Project')
project = Path(sys.argv[1]).resolve()
res_src = Path(__file__).resolve().parent / 'app' / 'src' / 'main' / 'res'
res_dst = project / 'app' / 'src' / 'main' / 'res'
if not (project / 'app' / 'src' / 'main' / 'AndroidManifest.xml').is_file():
    raise SystemExit(f'Android project not found: {project}')
for p in res_src.rglob('*'):
    if p.is_file():
        dest = res_dst / p.relative_to(res_src)
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(p, dest)
manifest = project / 'app' / 'src' / 'main' / 'AndroidManifest.xml'
tree = ET.parse(manifest)
root = tree.getroot()
ns = '{http://schemas.android.com/apk/res/android}'
app = root.find('application')
if app is None:
    raise SystemExit('No <application> element in AndroidManifest.xml')
app.set(ns+'icon', '@mipmap/ic_launcher')
app.set(ns+'roundIcon', '@mipmap/ic_launcher')
tree.write(manifest, encoding='utf-8', xml_declaration=True)
print('MANA icon resources copied and manifest updated.')
