# MANA Cloud Gateway 4.0

Это исходник облачного шлюза, а не уже опубликованный сайт или работающий сервер. Развёртывание требует хостинга, домена и секретов владельца.

## Запуск
1. Используй Node.js 20+ или Docker.
2. Скопируй `.env.example` в `.env` и задай параметры провайдера.
3. Запусти `npm start` или собери Docker image.
4. Опубликуй сервис за HTTPS reverse proxy.
5. В приложении MANA открой «Настроить MANA Cloud» и укажи HTTPS URL.

`MANA_MODEL_API_KEY` хранится только на сервере. Не помещай его в APK. Если `MANA_CLIENT_TOKEN` задан, клиент передаёт его как Bearer token. Для публичного развёртывания добавь rate limiting, учёт пользователей, квоты, аудит, защиту от злоупотреблений и постоянное хранилище.

Endpoints: `GET /health`, `GET /v1/capabilities`, `POST /v1/chat/completions` (OpenAI-compatible upstream).
