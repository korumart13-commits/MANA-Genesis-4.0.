import http from 'node:http';
import { randomUUID } from 'node:crypto';

const port = Number(process.env.PORT || 8080);
const clientToken = process.env.MANA_CLIENT_TOKEN || '';
const modelUrl = process.env.MANA_MODEL_BASE_URL || '';
const modelKey = process.env.MANA_MODEL_API_KEY || '';
const modelName = process.env.MANA_MODEL_NAME || '';
const json = (res, code, body) => { res.writeHead(code, {'content-type':'application/json; charset=utf-8'}); res.end(JSON.stringify(body)); };
const server = http.createServer(async (req, res) => {
  if (req.method === 'GET' && req.url === '/health') return json(res, 200, {service:'MANA Cloud', status:'ok', requestId:randomUUID()});
  if (req.method === 'GET' && req.url === '/v1/capabilities') return json(res, 200, {localFirst:true, cloudInference:Boolean(modelUrl && modelKey && modelName), features:['chat-completions','capability-discovery'], updates:'signed-manifest-required'});
  if (req.method !== 'POST' || req.url !== '/v1/chat/completions') return json(res, 404, {error:'not_found'});
  if (clientToken && req.headers.authorization !== `Bearer ${clientToken}`) return json(res, 401, {error:'unauthorized'});
  if (!modelUrl || !modelKey || !modelName) return json(res, 503, {error:'model_provider_not_configured'});
  let raw=''; for await (const chunk of req) { raw += chunk; if (raw.length > 1_000_000) return json(res, 413, {error:'request_too_large'}); }
  let payload; try { payload=JSON.parse(raw); } catch { return json(res, 400, {error:'invalid_json'}); }
  if (!Array.isArray(payload.messages)) return json(res, 400, {error:'messages_required'});
  try {
    const upstream = await fetch(`${modelUrl.replace(/\/$/,'')}/chat/completions`, {method:'POST', headers:{'content-type':'application/json','authorization':`Bearer ${modelKey}`}, body:JSON.stringify({...payload, model:modelName})});
    const body = await upstream.text();
    res.writeHead(upstream.status, {'content-type':upstream.headers.get('content-type') || 'application/json'}); res.end(body);
  } catch (error) { json(res, 502, {error:'upstream_unavailable', message:String(error).slice(0,300)}); }
});
server.listen(port, '0.0.0.0', () => console.log(`MANA Cloud listening on ${port}`));
