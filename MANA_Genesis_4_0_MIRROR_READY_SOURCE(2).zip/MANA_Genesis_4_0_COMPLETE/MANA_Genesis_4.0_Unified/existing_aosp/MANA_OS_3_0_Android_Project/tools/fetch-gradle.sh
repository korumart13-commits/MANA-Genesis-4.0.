#!/usr/bin/env bash
# Download the pinned Gradle distribution from a mirror first, verify SHA-256,
# then fall back to Gradle's direct download host. Never execute an unverified ZIP.
set -euo pipefail
VERSION="8.11.1"
FILE="gradle-${VERSION}-bin.zip"
SHA256="f397b287023acdba1e9f6fc5ea72d22dd63669d59ed4a289a29b1a76eee151c6"
CACHE_DIR="${GRADLE_DIST_CACHE:-${HOME}/.cache/mana-gradle}"
DEST="${CACHE_DIR}/${FILE}"
mkdir -p "$CACHE_DIR"
verify() { echo "${SHA256}  $1" | sha256sum -c - >/dev/null; }
if [[ -s "$DEST" ]] && verify "$DEST"; then
  echo "Using verified cached Gradle ${VERSION}: $DEST"
  exit 0
fi
rm -f "$DEST" "$DEST.part"
URLS=(
  "https://mirrors.huaweicloud.com/repository/toolkit/gradle/${FILE}"
  "https://downloads.gradle.org/distributions/${FILE}"
)
for url in "${URLS[@]}"; do
  echo "Trying ${url}"
  if curl --fail --location --retry 2 --connect-timeout 20 --max-time 900 "$url" -o "$DEST.part"; then
    if verify "$DEST.part"; then
      mv "$DEST.part" "$DEST"
      echo "Verified Gradle ${VERSION}: $DEST"
      exit 0
    fi
    echo "Checksum mismatch; rejecting download from ${url}" >&2
  fi
  rm -f "$DEST.part"
done
echo "Unable to obtain a verified Gradle ${VERSION} distribution." >&2
exit 1
