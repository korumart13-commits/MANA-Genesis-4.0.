# MANA Genesis 4.0 — статус попытки сборки

Дата: 2026-11-25

## Подготовлено
- Добавлены `gradlew`, `gradlew.bat`, `gradle/wrapper/gradle-wrapper.jar`.
- Настроен Gradle Wrapper на Gradle 8.11.1 (`services.gradle.org`).
- В проекте сохранены AGP 8.10.1, Kotlin 2.0.21, compileSdk/targetSdk 36, minSdk 29.
- Среда имеет OpenJDK 21.

## Проверки, реально выполненные
- XML-разбор всех XML-файлов проекта: успешно (11 файлов).
- Наличие build.gradle.kts и AndroidManifest.xml во всех пяти модулях: проверено.
- Запуск `./gradlew --version`: предпринят, завершился ошибкой загрузки Gradle.

## Блокирующая причина
Среда выполнения не имеет сетевого DNS-доступа: `UnknownHostException: services.gradle.org`; также не удалось разрешить `dl.google.com`. Поэтому Gradle 8.11.1 и Android SDK Platform 36 получить не удалось. В среде не найден установленный Gradle, `sdkmanager` или `android.jar`.

## Что НЕ подтверждено
- Gradle configuration/build.
- Компиляция Java/Kotlin.
- Android Lint и unit/instrumentation tests.
- Создание, установка или запуск debug APK.

**APK не собран.** Этот архив содержит подготовленный wrapper и отчёт о блокировке, но не является APK и не означает успешную компиляцию.

## Следующий необходимый шаг
Запустить этот проект в среде с доступом к `services.gradle.org`, `dl.google.com`, Google Maven и Maven Central, установить Android SDK Platform 36 и Build Tools, затем выполнить:

```bash
./gradlew --no-daemon clean testDebugUnitTest lintDebug assembleDebug
```

APK при успешной сборке ожидается в `app/build/outputs/apk/debug/app-debug.apk`.

## Local + Cloud expansion stage (2026-11-25)

- Added first-run welcome/setup screen and sequential Android runtime permission requests (notifications, microphone, camera, Bluetooth where supported).
- Added HOME/DEFAULT intent filter so Android can offer MANA as a home-screen app; the user must select it in system settings.
- Added Google Play launch action and HTTPS downloads through Android DownloadManager.
- Added HTTPS cloud URL setting and `ManaCloudClient` source for health checks and chat-completions requests.
- Added `cloud/` Node.js gateway source with health/capabilities and server-side model-provider proxy; provider secrets are server-only.
- Added `MANA_HYBRID_ARCHITECTURE_RU.md` defining Android as the retained system foundation and MANA as the control/interface layer.
- Static checks: AndroidManifest XML parsed successfully; Node.js server passed `node --check`.
- Android Gradle build was attempted but could not start because the environment cannot resolve `services.gradle.org`; therefore no APK build or Kotlin compilation is claimed.
- Cloud service is source-only and has not been deployed; it requires a host, HTTPS domain, provider credentials and security hardening.
