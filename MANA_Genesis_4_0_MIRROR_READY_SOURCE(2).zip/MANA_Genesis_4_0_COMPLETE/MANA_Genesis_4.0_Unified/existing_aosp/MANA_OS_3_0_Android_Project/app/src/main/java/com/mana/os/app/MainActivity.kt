package com.mana.os.app

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.app.DownloadManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import com.mana.os.core.MANA
import com.mana.os.core.ManaSystem
import com.mana.os.cloud.ManaCloudClient

/** MANA is an intelligent control layer over Android, not a replacement for its kernel. */
class MainActivity : Activity() {
    private val mana = ManaSystem()
    private val prefs by lazy { getSharedPreferences("mana_setup", MODE_PRIVATE) }
    private lateinit var root: LinearLayout
    private val requestedPermissions = mutableListOf<String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (!prefs.getBoolean("intro_seen", false)) showWelcome() else showDashboard()
    }

    private fun base(title: String, subtitle: String? = null) {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(24, 34, 24, 24)
            setBackgroundColor(android.graphics.Color.parseColor(MANA.Colors.BACKGROUND))
        }
        root.addView(TextView(this).apply {
            text = title; textSize = 34f; gravity = Gravity.CENTER
            setTextColor(android.graphics.Color.parseColor(MANA.Colors.ACCENT))
        }, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        if (subtitle != null) root.addView(TextView(this).apply {
            text = subtitle; textSize = 14f; gravity = Gravity.CENTER
            setPadding(0, 12, 0, 18)
            setTextColor(android.graphics.Color.parseColor(MANA.Colors.TEXT))
        })
        setContentView(root)
    }

    private fun showWelcome() {
        base("MANA", "Первоначальная настройка
Я стану твоим главным интерфейсом, сохраняя Android в качестве системной основы.")
        addText("Android продолжит обеспечивать ядро, драйверы, безопасность, установку приложений и совместимость с Google Play. MANA будет постепенно брать на себя интерфейс и доступные функции управления.")
        addButton("Начать настройку и выдать разрешения") {
            prefs.edit().putBoolean("intro_seen", true).apply()
            requestOptionalPermissions()
        }
        addButton("Продолжить без необязательных разрешений") {
            prefs.edit().putBoolean("intro_seen", true).apply(); showDashboard()
        }
        addText("Разрешения выдаются системными окнами Android. Можно отказать и включить их позже в настройках.")
    }

    private fun requestOptionalPermissions() {
        val candidates = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= 33) candidates += Manifest.permission.POST_NOTIFICATIONS
        candidates += Manifest.permission.RECORD_AUDIO
        candidates += Manifest.permission.CAMERA
        if (Build.VERSION.SDK_INT >= 31) {
            candidates += Manifest.permission.BLUETOOTH_CONNECT
            candidates += Manifest.permission.BLUETOOTH_SCAN
        }
        requestedPermissions.clear()
        requestedPermissions += candidates.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        requestNextPermission()
    }

    private fun requestNextPermission() {
        if (requestedPermissions.isEmpty()) { showDashboard(); return }
        val permission = requestedPermissions.removeAt(0)
        requestPermissions(arrayOf(permission), 4101)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 4101) requestNextPermission()
    }

    private fun showDashboard() {
        base("MANA", "MANA Genesis 4.0 • интеллектуальный слой управления Android")
        addText("Ядро Android остаётся активным: MANA управляет доступными функциями через официальные API, а не отключает системные механизмы.")
        addButton("Открыть рабочий стол MANA") {
            try { startActivity(Intent(this, Class.forName("com.mana.os.launcher.ManaLauncherActivity"))) }
            catch (_: Exception) { Toast.makeText(this, "Модуль Launcher пока недоступен", Toast.LENGTH_LONG).show() }
        }
        addButton("Настроить MANA Cloud") { configureCloud() }
        addButton("Разрешения MANA") { startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))) }
        addButton("Сделать MANA основным экраном") { startActivity(Intent(Settings.ACTION_HOME_SETTINGS)) }
        addButton("Открыть Google Play") {
            try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("market://launch?id=com.android.vending"))) }
            catch (_: Exception) { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store"))) }
        }
        addButton("Скачать файл из интернета") { downloadFromUrl() }
        addButton("Открыть системный выбор файлов") {
            val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply { type = "*/*"; addCategory(Intent.CATEGORY_OPENABLE) }
            startActivityForResult(intent, 4102)
        }
        addButton("Проверить ядро MANA") {
            AlertDialog.Builder(this).setTitle("MANA Core").setMessage(mana.boot()).setPositiveButton("OK", null).show()
        }
        val cloudStatus = TextView(this).apply {
            text = "Проверка MANA Cloud…"; textSize = 13f; setPadding(0, 14, 0, 8)
            setTextColor(android.graphics.Color.parseColor(MANA.Colors.ACCENT))
        }
        root.addView(cloudStatus)
        val cloudUrl = prefs.getString("cloud_url", "").orEmpty()
        if (cloudUrl.isBlank()) {
            cloudStatus.text = "MANA Cloud не настроено. Local работает автономно."
        } else {
            ManaCloudClient(cloudUrl, prefs.getString("cloud_token", null)).checkHealth { ok, detail ->
                runOnUiThread { cloudStatus.text = if (ok) "MANA Cloud: подключено" else "MANA Cloud: недоступно ($detail)" }
            }
        }
    }

    private fun downloadFromUrl() {
        val input = EditText(this).apply { hint = "https://example.com/file.zip" }
        AlertDialog.Builder(this).setTitle("Загрузка файла")
            .setMessage("Файл будет загружен системным DownloadManager в папку Downloads.")
            .setView(input).setNegativeButton("Отмена", null)
            .setPositiveButton("Скачать") { _, _ ->
                val uri = runCatching { Uri.parse(input.text.toString().trim()) }.getOrNull()
                if (uri == null || uri.scheme != "https" || uri.host.isNullOrBlank()) {
                    Toast.makeText(this, "Укажи корректную HTTPS-ссылку", Toast.LENGTH_LONG).show()
                } else try {
                    val request = DownloadManager.Request(uri)
                        .setTitle(uri.lastPathSegment ?: "Файл MANA")
                        .setDescription("Загрузка через системную службу Android")
                        .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                        .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, uri.lastPathSegment ?: "mana-download")
                    (getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager).enqueue(request)
                    Toast.makeText(this, "Загрузка передана Android DownloadManager", Toast.LENGTH_SHORT).show()
                } catch (e: Exception) {
                    Toast.makeText(this, "Не удалось начать загрузку: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }.show()
    }

    private fun configureCloud() {
        val form = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 8, 24, 0) }
        val input = EditText(this).apply { hint = "https://api.example.com"; setText(prefs.getString("cloud_url", "")) }
        val token = EditText(this).apply {
            hint = "Токен доступа (если включён на сервере)"
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
            setText(prefs.getString("cloud_token", ""))
        }
        form.addView(input); form.addView(token)
        AlertDialog.Builder(this).setTitle("Подключение MANA Cloud")
            .setMessage("Введи HTTPS-адрес сервера и, если настроен, клиентский токен. Ключ AI-провайдера сюда вводить нельзя — он хранится только на сервере.")
            .setView(form).setNegativeButton("Отмена", null)
            .setPositiveButton("Сохранить") { _, _ ->
                val value = input.text.toString().trim().trimEnd('/')
                if (value.startsWith("https://")) {
                    prefs.edit().putString("cloud_url", value).putString("cloud_token", token.text.toString().trim()).apply()
                    Toast.makeText(this, "Параметры облака сохранены", Toast.LENGTH_SHORT).show()
                    showDashboard()
                } else Toast.makeText(this, "Нужен HTTPS-адрес сервера", Toast.LENGTH_LONG).show()
            }.show()
    }

    private fun addText(value: String) {
        root.addView(TextView(this).apply {
            text = value; textSize = 14f; setPadding(0, 12, 0, 12)
            setTextColor(android.graphics.Color.parseColor(MANA.Colors.TEXT))
        })
    }

    private fun addButton(label: String, action: () -> Unit) {
        root.addView(Button(this).apply { text = label; setOnClickListener { action() } },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = 8 })
    }
}
