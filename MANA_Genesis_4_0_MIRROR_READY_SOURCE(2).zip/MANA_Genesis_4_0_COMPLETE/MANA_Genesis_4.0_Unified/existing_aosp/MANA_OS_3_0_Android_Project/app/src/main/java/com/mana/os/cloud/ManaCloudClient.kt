package com.mana.os.cloud

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

/** HTTPS-only client. Provider credentials stay on the cloud gateway, never in this APK. */
class ManaCloudClient(private val baseUrl: String, private val clientToken: String? = null) {
    private val executor = Executors.newSingleThreadExecutor()

    fun checkHealth(callback: (Boolean, String) -> Unit) = executor.execute {
        try {
            val response = request("/health", "GET", null)
            callback(true, response)
        } catch (e: Exception) {
            callback(false, e.message ?: "Cloud unavailable")
        }
    }

    fun sendMessage(message: String, callback: (String?, String?) -> Unit) = executor.execute {
        try {
            val payload = JSONObject()
                .put("messages", org.json.JSONArray().put(JSONObject().put("role", "user").put("content", message)))
                .put("temperature", 0.7)
            val raw = request("/v1/chat/completions", "POST", payload.toString())
            val json = JSONObject(raw)
            val answer = json.optJSONArray("choices")?.optJSONObject(0)
                ?.optJSONObject("message")?.optString("content")
            if (answer.isNullOrBlank()) callback(null, "Cloud returned no message") else callback(answer, null)
        } catch (e: Exception) {
            callback(null, e.message ?: "Cloud request failed")
        }
    }

    private fun request(path: String, method: String, body: String?): String {
        require(baseUrl.startsWith("https://")) { "MANA Cloud requires HTTPS" }
        val connection = (URL(baseUrl.trimEnd('/') + path).openConnection() as HttpURLConnection).apply {
            requestMethod = method
            connectTimeout = 12_000
            readTimeout = 45_000
            setRequestProperty("Accept", "application/json")
            clientToken?.takeIf { it.isNotBlank() }?.let { setRequestProperty("Authorization", "Bearer $it") }
            if (body != null) {
                doOutput = true
                setRequestProperty("Content-Type", "application/json; charset=utf-8")
            }
        }
        try {
            if (body != null) connection.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val text = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
            if (code !in 200..299) error("MANA Cloud HTTP $code: ${text.take(300)}")
            return text
        } finally { connection.disconnect() }
    }
}
