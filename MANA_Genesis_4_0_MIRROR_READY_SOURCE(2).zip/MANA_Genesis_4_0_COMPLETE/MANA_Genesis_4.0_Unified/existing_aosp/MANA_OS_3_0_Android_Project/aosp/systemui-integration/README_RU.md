# Интеграция собственного MANA UI с AOSP SystemUI

## Безопасная стратегия

На первом этапе не заменять APK `com.android.systemui`. Сохранить штатный AOSP
SystemUI: он обслуживает Keyguard, статус-бар, QS, power menu, emergency UI,
системные подтверждения и критичные сценарии. Текущий Android Studio модуль
`systemui` — companion/notification-listener, а не системная панель и не имеет
автоматического доступа к приватным API. Notification Access пользователь
включает самостоятельно в Settings.

## План настоящей интеграции

1. Зафиксировать AOSP tag/branch, device, product, SDK, архитектуру и текущий SystemUI.
2. Собрать чистый образ и сохранить его как контрольную точку.
3. Внутри `frameworks/base/packages/SystemUI` добавить отдельный Soong-модуль
   `ManaSystemUIExt` либо ветко-совместимое расширение, не подменяя пакет целиком.
4. Подключать узкие UI-компоненты через существующие контроллеры/плагины выбранной
   ветки; не переносить внутренние классы SystemUI между версиями Android.
5. Применять брендинг через RRO только к ресурсам, объявленным overlayable.
6. Оставить Keyguard, emergency UI, power menu и системные permission prompts штатными
   до отдельного security review.
7. Тестировать notifications, QS, multi-user, accessibility, emergency calls,
   boot flow, CTS/VTS и OTA rollback.
8. Подписывать release images ключами продукта, сохранить AVB и rollback protection.

Запрещённые сокращения: удаление штатного SystemUI, отключение SELinux/AVB/dm-verity,
подмена системного APK companion-приложением или выдача platform permissions без нужды.
