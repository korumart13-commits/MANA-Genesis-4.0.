# Device tree placeholder

Target label supplied by the user: realme RMX5566 / realme C85 5G.

The exact codename, board platform, partition layout, boot image header version, kernel, vendor interface, and firmware branch have not been verified. Therefore no `BoardConfig.mk`, `device.mk`, product makefile, init scripts, fstab, sepolicy, overlays, or proprietary-file list is fabricated here.

This directory is intentionally not buildable until those inputs are verified.
