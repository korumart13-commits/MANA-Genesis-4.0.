package com.mana.genesis;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Typeface;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

/**
 * MANA Genesis 4.0 main screen.
 * Required project classes: ManaCore, ManaMemory, ManaSettings, ManaTheme.
 * Optional module Activities are resolved at runtime and must be included
 * in the APK and declared in AndroidManifest.xml.
 */
public class MainActivity extends Activity {

    private static final int PAGE_HOME = 0;
    private static final int PAGE_CHAT = 1;
    private static final int PAGE_MEMORY = 2;
    private static final int PAGE_MODULES = 3;
    private static final int PAGE_SETTINGS = 4;

    private ManaCore mana;
    private LinearLayout content;
    private TextView status;
    private TextView conversation;
    private EditText chatInput;
    private int currentPage = PAGE_HOME;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mana = ManaCore.getInstance(getApplicationContext());
        buildLayout();
        openPage(PAGE_HOME);
    }

    private void buildLayout() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(ManaTheme.BACKGROUND);

        TextView header = new TextView(this);
        header.setText("MANA");
        header.setTextColor(ManaTheme.ACCENT);
        header.setTextSize(28);
        header.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        header.setGravity(Gravity.CENTER);
        header.setPadding(16, 18, 16, 6);

        status = new TextView(this);
        status.setText("MANA " + mana.getVersion() + " • готова к работе");
        status.setTextColor(ManaTheme.TEXT);
        status.setTextSize(12);
        status.setGravity(Gravity.CENTER);
        status.setPadding(8, 4, 8, 12);

        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(16, 12, 16, 16);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.addView(content);

        LinearLayout navigation = new LinearLayout(this);
        navigation.setOrientation(LinearLayout.HORIZONTAL);
        navigation.setBackgroundColor(ManaTheme.SURFACE);
        addNavigationButton(navigation, "Главная", PAGE_HOME);
        addNavigationButton(navigation, "Чат", PAGE_CHAT);
        addNavigationButton(navigation, "Память", PAGE_MEMORY);
        addNavigationButton(navigation, "Модули", PAGE_MODULES);
        addNavigationButton(navigation, "Настройки", PAGE_SETTINGS);

        root.addView(header);
        root.addView(status);
        root.addView(scroll, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1));
        root.addView(navigation);
        setContentView(root);
    }

    private void addNavigationButton(
            LinearLayout parent, String label, int page) {
        Button button = new Button(this);
        button.setText(label);
        button.setTextSize(10);
        button.setAllCaps(false);
        button.setMinWidth(0);
        button.setPadding(2, 4, 2, 4);
        button.setTextColor(ManaTheme.TEXT);
        button.setBackgroundTintList(
                ColorStateList.valueOf(ManaTheme.SURFACE));
        button.setOnClickListener(view -> openPage(page));
        parent.addView(button, new LinearLayout.LayoutParams(
                0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));
    }

    private void openPage(int page) {
        currentPage = page;
        switch (page) {
            case PAGE_HOME: showHome(); break;
            case PAGE_CHAT: showChat(); break;
            case PAGE_MEMORY: showMemory(); break;
            case PAGE_MODULES: showModules(); break;
            case PAGE_SETTINGS: showSettings(); break;
            default:
                currentPage = PAGE_HOME;
                showHome();
                break;
        }
    }

    private void preparePage(String title) {
        content.removeAllViews();
        TextView heading = new TextView(this);
        heading.setText(title);
        heading.setTextColor(ManaTheme.ACCENT);
        heading.setTextSize(23);
        heading.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        heading.setPadding(0, 8, 0, 16);
        content.addView(heading);
    }

    private TextView makeText(String value, int size) {
        TextView view = new TextView(this);
        view.setText(value);
        view.setTextColor(ManaTheme.TEXT);
        view.setTextSize(size);
        view.setPadding(4, 8, 4, 8);
        return view;
    }

    private Button makeButton(String label, Runnable action) {
        Button button = new Button(this);
        button.setText(label);
        button.setAllCaps(false);
        button.setTextColor(ManaTheme.TEXT);
        button.setBackgroundTintList(
                ColorStateList.valueOf(ManaTheme.PRIMARY));
        button.setOnClickListener(view -> action.run());
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        params.setMargins(0, 5, 0, 5);
        button.setLayoutParams(params);
        return button;
    }

    private void showHome() {
        preparePage("Главная");
        content.addView(makeText(
                "Я MANA — единый центр твоего цифрового пространства.", 16));
        content.addView(makeText("Версия: " + mana.getVersion(), 14));
        content.addView(makeButton("Открыть чат",
                () -> openPage(PAGE_CHAT)));
        content.addView(makeButton("Голосовой помощник",
                () -> launchModule("ManaVoiceActivity")));
        content.addView(makeButton("Подключённые устройства",
                () -> launchModule("ManaConnectActivity")));
        content.addView(makeButton("Life Studio",
                () -> launchModule("ManaLifeStudioActivity")));
        content.addView(makeButton("Моя память",
                () -> openPage(PAGE_MEMORY)));
        content.addView(makeButton("Настройки MANA",
                () -> openPage(PAGE_SETTINGS)));
    }

    private void showChat() {
        preparePage("Чат с MANA");
        conversation = makeText(
                "MANA: Привет! Я здесь. О чём поговорим?", 16);
        content.addView(conversation);

        chatInput = new EditText(this);
        chatInput.setHint("Напиши сообщение...");
        chatInput.setTextColor(ManaTheme.TEXT);
        chatInput.setHintTextColor(0xFF91A9C5);
        chatInput.setSingleLine(false);
        chatInput.setMinLines(2);
        chatInput.setPadding(10, 8, 10, 8);
        chatInput.setBackgroundTintList(
                ColorStateList.valueOf(ManaTheme.ACCENT));
        content.addView(chatInput);

        content.addView(makeButton("Отправить", this::sendChatMessage));
        content.addView(makeButton(
                "Сохранить введённый текст в памяти", this::saveChatInput));
        content.addView(makeButton(
                "Голосовой ввод",
                () -> launchModule("ManaVoiceActivity")));
    }

    private void sendChatMessage() {
        if (chatInput == null || conversation == null) return;
        String message = chatInput.getText().toString().trim();
        if (message.isEmpty()) return;
        conversation.append("\n\nТы: " + message);
        conversation.append("\n\nMANA: " + mana.respond(message));
        chatInput.setText("");
    }

    private void saveChatInput() {
        if (chatInput == null || conversation == null) return;
        String message = chatInput.getText().toString().trim();
        if (message.isEmpty()) {
            Toast.makeText(this, "Сначала введи текст.",
                    Toast.LENGTH_SHORT).show();
            return;
        }
        if (!mana.getSettings().isMemoryEnabled()) {
            conversation.append(
                    "\n\nMANA: Локальная память отключена в настройках.");
            return;
        }
        mana.getMemory().save(message);
        conversation.append(
                "\n\nMANA: Сохранила текст в локальной памяти.");
        chatInput.setText("");
    }

    private void showMemory() {
        preparePage("Локальная память");
        if (!mana.getSettings().isMemoryEnabled()) {
            content.addView(makeText(
                    "Память отключена. Включи её в настройках MANA.", 15));
            return;
        }

        List<String> notes = mana.getMemory().getAll();
        if (notes == null || notes.isEmpty()) {
            content.addView(makeText(
                    "Пока здесь нет сохранённых заметок.", 15));
        } else {
            for (int i = 0; i < notes.size(); i++) {
                content.addView(makeText(
                        (i + 1) + ". " + notes.get(i), 15));
            }
        }

        content.addView(makeButton("Очистить память", () ->
                new AlertDialog.Builder(this)
                        .setTitle("Очистить память?")
                        .setMessage(
                                "Все локально сохранённые заметки MANA будут удалены.")
                        .setNegativeButton("Отмена", null)
                        .setPositiveButton("Очистить", (dialog, which) -> {
                            mana.getMemory().clear();
                            showMemory();
                        })
                        .show()));
    }

    private void showModules() {
        preparePage("Модули MANA");
        content.addView(makeText(
                "Модули используют общую оболочку и имя MANA.", 15));
        content.addView(makeButton("MANA Voice",
                () -> launchModule("ManaVoiceActivity")));
        content.addView(makeButton("MANA Connect",
                () -> launchModule("ManaConnectActivity")));
        content.addView(makeButton("MANA Life Studio",
                () -> launchModule("ManaLifeStudioActivity")));
        content.addView(makeText(
                "Аватар, дневник и расширенные интеллектуальные функции "
                        + "пока не подключены к этому экрану.", 13));
    }

    private void showSettings() {
        preparePage("Настройки MANA");
        ManaSettings settings = mana.getSettings();
        content.addView(makeText("Личность MANA", 16));
        content.addView(makeText(
                "Текущий характер: " + settings.getPersonality(), 14));

        content.addView(makeButton("Игривая личность", () -> {
            settings.setPersonality("playful");
            showSettings();
        }));
        content.addView(makeButton("Спокойная личность", () -> {
            settings.setPersonality("calm");
            showSettings();
        }));

        content.addView(makeText(
                "Локальная память: "
                        + (settings.isMemoryEnabled()
                        ? "включена" : "отключена"), 14));
        content.addView(makeButton(
                settings.isMemoryEnabled()
                        ? "Отключить память" : "Включить память",
                () -> {
                    settings.setMemoryEnabled(!settings.isMemoryEnabled());
                    showSettings();
                }));

        content.addView(makeButton(
                "Системные настройки Bluetooth",
                this::openBluetoothSettings));
        content.addView(makeText(
                "MANA Genesis " + mana.getVersion(), 14));
    }

    private void launchModule(String simpleClassName) {
        String fullClassName = "com.mana.genesis." + simpleClassName;
        try {
            Class<?> activityClass = Class.forName(fullClassName);
            if (!Activity.class.isAssignableFrom(activityClass)) {
                throw new ClassNotFoundException(
                        simpleClassName + " не является Activity");
            }
            startActivity(new Intent(this, activityClass));
        } catch (ClassNotFoundException exception) {
            new AlertDialog.Builder(this)
                    .setTitle("Модуль пока недоступен")
                    .setMessage(simpleClassName
                            + " ещё не добавлен в сборку MANA. "
                            + "Добавь его исходный файл и запись "
                            + "в AndroidManifest.xml.")
                    .setPositiveButton("Понятно", null)
                    .show();
        } catch (RuntimeException exception) {
            Toast.makeText(this,
                    "Не удалось открыть модуль: " + exception.getMessage(),
                    Toast.LENGTH_LONG).show();
        }
    }

    private void openBluetoothSettings() {
        try {
            startActivity(new Intent(Settings.ACTION_BLUETOOTH_SETTINGS));
        } catch (RuntimeException exception) {
            startActivity(new Intent(Settings.ACTION_SETTINGS));
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (status != null && mana != null) {
            status.setText(
                    "MANA " + mana.getVersion() + " • готова к работе");
        }
    }

    @Override
    public void onBackPressed() {
        if (currentPage != PAGE_HOME) {
            openPage(PAGE_HOME);
        } else {
            super.onBackPressed();
        }
    }
}
