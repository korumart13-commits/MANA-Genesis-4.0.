package com.example.assistant

import android.app.Service\nimport android.app.Notification\nimport android.app.NotificationChannel\nimport android.app.NotificationManager\nimport android.app.PendingIntent
import android.content.Intent
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import android.widget.Toast

/** Видимая плавающая кнопка вызова Маны поверх других приложений. */
class FloatingManaService : Service() {
    private lateinit var wm: WindowManager
    private var bubble: View? = null
    private var params: WindowManager.LayoutParams? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "stop") { stopSelf(); return START_NOT_STICKY }
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(
            NotificationChannel("mana_float", "Плавающая Мана", NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(this, 81,
            Intent(this, FloatingManaService::class.java).setAction("stop"),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val notification = if (Build.VERSION.SDK_INT >= 26)
            Notification.Builder(this, "mana_float")
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle("Мана активна")
                .setContentText("Плавающая кнопка доступна поверх экрана")
                .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Выключить", stop).build()
        else Notification.Builder(this).setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("Мана активна").setContentText("Плавающая кнопка доступна").build()
        startForeground(82, notification)
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Разрешите показ поверх других приложений для плавающей Маны", Toast.LENGTH_LONG).show()
            stopSelf()
            return START_NOT_STICKY
        }
        if (bubble == null) showBubble()
        return START_STICKY
    }

    private fun showBubble() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val size = (58 * resources.displayMetrics.density).toInt()
        val v = TextView(this).apply {
            text = "М"
            textSize = 25f
            setTextColor(0xFFFFEAF0.toInt())
            gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(0xFF542A3B.toInt())
                setStroke((2 * resources.displayMetrics.density).toInt(), 0xFFE7A4B8.toInt())
            }
            elevation = 12f
            contentDescription = "Вызвать Ману"
        }
        val type = if (Build.VERSION.SDK_INT >= 26)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else WindowManager.LayoutParams.TYPE_PHONE
        val p = WindowManager.LayoutParams(size, size, type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.START
            x = resources.displayMetrics.widthPixels - size - 12
            y = resources.displayMetrics.heightPixels / 3
        }
        var downX = 0f; var downY = 0f; var startX = 0; var startY = 0; var moved = false
        v.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX; downY = e.rawY; startX = p.x; startY = p.y; moved = false; true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - downX).toInt(); val dy = (e.rawY - downY).toInt()
                    if (kotlin.math.abs(dx) + kotlin.math.abs(dy) > 10) moved = true
                    p.x = startX + dx; p.y = startY + dy
                    wm.updateViewLayout(v, p); true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) {
                        startActivity(Intent(this, MainActivity::class.java)
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                            .putExtra("assist", true))
                    }
                    true
                }
                else -> true
            }
        }
        bubble = v; params = p
        wm.addView(v, p)
    }

    override fun onDestroy() {
        bubble?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        bubble = null
        super.onDestroy()
    }
}
