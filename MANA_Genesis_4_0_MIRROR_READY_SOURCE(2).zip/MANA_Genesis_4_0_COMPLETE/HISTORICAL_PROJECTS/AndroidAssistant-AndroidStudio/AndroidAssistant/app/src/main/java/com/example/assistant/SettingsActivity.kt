package com.example.assistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class SettingsActivity : Activity() {
    private lateinit var status: TextView

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        window.statusBarColor = getColor(R.color.bg_top)
        window.navigationBarColor = getColor(R.color.bg_bottom)
        val sp = getSharedPreferences("cfg", MODE_PRIVATE)

        fun label(t: String) = TextView(this).apply {
            text = t; setTextColor(0xB3FFFFFF.toInt()); textSize = 13f; setPadding(dp(4), dp(16), 0, dp(4))
        }
        fun field(hint: String, value: String) = EditText(this).apply {
            setHint(hint); setText(value); setTextColor(Color.WHITE); setHintTextColor(0x99FFFFFF.toInt())
            setBackgroundResource(R.drawable.panel_glass); setPadding(dp(16), dp(12), dp(16), dp(12))
        }
        fun btn(t: String, f: () -> Unit) = Button(this).apply {
            text = t; isAllCaps = false; setTextColor(Color.WHITE)
            setBackgroundResource(R.drawable.panel_glass); setOnClickListener { f() }
        }

        val nameField = field("Имя ассистента", Cfg.name(this))
        val keyField = field("API-ключ Claude (необязательно)", sp.getString("key", "") ?: "").apply {
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        status = TextView(this).apply { setTextColor(Color.WHITE); textSize = 14f; setPadding(dp(4), dp(16), dp(4), 0) }

        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(24))
            addView(TextView(context).apply { text = "Настройки"; setTextColor(Color.WHITE); textSize = 22f })

            addView(label("Имя: на него отзываюсь, когда включено прослушивание"))
            addView(nameField)
            addView(btn("Сохранить имя") {
                sp.edit().putString("name", nameField.text.toString().trim().ifBlank { Cfg.NAME }).apply()
                status.text = "Имя сохранено."
            })

            addView(label("Ключ Claude нужен только для свободного разговора. Без него я работаю по готовым командам"))
            addView(keyField)
            addView(btn("Сохранить ключ") {
                sp.edit().putString("key", keyField.text.toString().trim()).apply()
                status.text = "Ключ сохранён."
            })

            addView(label("Доступы"))
            addView(btn("1. Доступ к управлению экраном") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) })
            addView(btn("2. Сделать основным помощником") {
                openFirst(Settings.ACTION_VOICE_INPUT_SETTINGS,
                    Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS, Settings.ACTION_SETTINGS) })
            addView(btn("3. Слушать моё имя (вкл/выкл)") { toggleListen() })

            addView(label("Память"))
            addView(btn("Стереть память и выученные команды") {
                Memory.clear(this@SettingsActivity); Learn.clearAll(this@SettingsActivity)
                status.text = "Память очищена."
            })
            addView(status)
        }
        setContentView(ScrollView(this).apply {
            setBackgroundResource(R.drawable.bg_gradient)
            addView(box)
        })
    }

    private fun openFirst(vararg actions: String) {
        for (a in actions) {
            try { startActivity(Intent(a)); return } catch (e: Exception) { }
        }
    }

    private fun toggleListen() {
        if (ListenService.running) {
            stopService(Intent(this, ListenService::class.java))
            status.text = "Прослушивание выключено."
            return
        }
        val need = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33) need.add(Manifest.permission.POST_NOTIFICATIONS)
        val missing = need.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isNotEmpty()) { requestPermissions(missing.toTypedArray(), 2); return }
        startListen()
    }

    private fun startListen() {
        startForegroundService(Intent(this, ListenService::class.java))
        status.text = "Слушаю. Скажите: «${Cfg.name(this)}, который час»."
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(code, perms, res)
        if (code != 2) return
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) startListen()
        else status.text = "Без доступа к микрофону слушать имя не получится."
    }
}
