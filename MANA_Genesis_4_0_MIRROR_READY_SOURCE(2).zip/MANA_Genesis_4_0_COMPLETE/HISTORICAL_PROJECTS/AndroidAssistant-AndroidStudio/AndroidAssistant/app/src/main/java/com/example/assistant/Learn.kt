package com.example.assistant

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Всё, чему ассистент научился у пользователя: свои команды, номера, непонятые фразы. */
object Learn {
    private fun sp(c: Context) = c.getSharedPreferences("learn", Context.MODE_PRIVATE)
    private fun obj(c: Context, k: String): JSONObject =
        try { JSONObject(sp(c).getString(k, "{}") ?: "{}") } catch (e: Exception) { JSONObject() }
    private fun save(c: Context, k: String, o: JSONObject) { sp(c).edit().putString(k, o.toString()).apply() }
    private fun keys(o: JSONObject): List<String> {
        val n = o.names() ?: return emptyList()
        return (0 until n.length()).map { n.getString(it) }
    }

    // «когда я говорю X, делай Y»
    fun addMacro(c: Context, phrase: String, cmd: String) { val o = obj(c, "macros"); o.put(phrase, cmd); save(c, "macros", o) }
    fun macro(c: Context, phrase: String): String? = obj(c, "macros").optString(phrase, "").takeIf { it.isNotEmpty() }
    fun removeMacro(c: Context, phrase: String): Boolean {
        val o = obj(c, "macros")
        if (!o.has(phrase)) return false
        o.remove(phrase); save(c, "macros", o); return true
    }
    fun macros(c: Context): List<Pair<String, String>> { val o = obj(c, "macros"); return keys(o).map { Pair(it, o.getString(it)) } }

    // «запомни номер мамы +7…»
    fun addContact(c: Context, name: String, num: String) { val o = obj(c, "contacts"); o.put(name.lowercase(), num); save(c, "contacts", o) }
    fun contact(c: Context, name: String): String? {
        val o = obj(c, "contacts")
        val k = keys(o).firstOrNull { Parse.same(it, name) } ?: return null
        return o.getString(k)
    }
    fun contactNames(c: Context): List<String> = keys(obj(c, "contacts"))

    // Фразы, которые ассистент не понял: их можно показать и добавить в программу
    fun logUnknown(c: Context, phrase: String) {
        val l = unknown(c).toMutableList()
        if (phrase !in l) l.add(phrase)
        sp(c).edit().putString("unknown", JSONArray(l.takeLast(30)).toString()).apply()
    }
    fun unknown(c: Context): List<String> {
        val a = try { JSONArray(sp(c).getString("unknown", "[]") ?: "[]") } catch (e: Exception) { JSONArray() }
        return (0 until a.length()).map { a.getString(it) }
    }
    fun clearUnknown(c: Context) { sp(c).edit().remove("unknown").apply() }
    fun clearAll(c: Context) { sp(c).edit().clear().apply() }
}
