# MANA Mobile Installer 1.1.0 — диагностика совместимости

## Что добавлено
- Сбор read-only build properties: product/device/model, build fingerprint/type/tags, vendor fingerprint, bootloader, platform, security patch, slot и AVB-состояние.
- Проверка признаков user/release-keys как **косвенного** индикатора заводской сборки. Это не аутентификация прошивки.
- Поиск доступных VINTF manifest XML в vendor/odm/system/system_ext и SHA-256 доступного содержимого.
- Извлечение деклараций HAL из доступных VINTF XML (не подтверждает запуск HAL-сервисов).
- Сведения о ядре из `/proc/version`, `os.version` и ABI.
- Read-only попытка перечислить доступные каталоги by-name для разделов.
- AVB/Verified Boot свойства: verifiedbootstate, flash.locked, vbmeta.device_state, veritymode, slot.
- Подробный текстовый отчёт через системный SAF picker.

## Ограничения Android
Обычное приложение без root/привилегий может не иметь доступа к `/vendor`, `/odm`, `/dev/block` и runtime HAL inventory. Недоступность отображается как UNKNOWN/PARTIAL, не как PASS. Доступность зависит от версии Android и политики конкретной прошивки.

## Что нужно для настоящего заключения
1. Официальный пакет заводской прошивки realme для точной модели, региона и аппаратной ревизии.
2. Проверка подписи/хешей и метаданных OTA относительно доверенного источника.
3. Сравнение framework/vendor/odm VINTF и запуск `checkvintf` в соответствующей build environment.
4. Kernel source/config, device tree, kernel modules, vendor_boot/init_boot и HAL manifest для той же ревизии.
5. Точные partition sizes/offsets, A/B layout, dynamic partition metadata, fstab и AVB descriptors/rollback indexes.

Приложение намеренно не выполняет прошивку, fastboot, root, unlock, изменение AVB/SELinux или запись разделов. Статус READY TO FLASH автоматически не выставляется.
