# MANA OS 3.0 — AOSP integration notes

## Что переводить в AOSP

| Компонент | Интеграция | Статус этого репозитория |
|---|---|---|
| Launcher | Предустановленный HOME app / PRODUCT_PACKAGES | Базовая Activity есть |
| Settings | Отдельный пакет или изменения AOSP Settings | Только MANA settings screen |
| SystemUI | Форк packages/SystemUI, overlays, resource/config changes | Только NotificationListenerService |
| Permissions | PermissionController/PackageManager policy в AOSP | Только внутренний state manager |
| Receptionist | Telecom framework integration + role/privileged permissions | Только бизнес-логика |
| OTA/Recovery | AOSP OTA tooling, update_engine, recovery/boot control | Не реализовано |

## Пример направления product makefile (не готовый файл устройства)

```makefile
PRODUCT_PACKAGES += \\
    ManaLauncher \\
    ManaSettings
```

Реальные имена Soong-модулей и системные package targets должны быть согласованы с выбранной веткой AOSP. Android Studio Gradle-модули напрямую не становятся AOSP system packages без отдельной интеграции/адаптации.

## Безопасность

- Не отключать SELinux enforcing и Android Verified Boot.
- Не использовать vendor/kernel/HAL от другого устройства.
- Не включать platform signing keys в публичный репозиторий.
- Не запрашивать privileged permissions без необходимости и явного назначения.
- OTA-пакет должен быть привязан к устройству, подписан и проверен до записи разделов.
