plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.mana.os"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.mana.os"
        minSdk = 29
        targetSdk = 35
        versionCode = 30
        versionName = "3.0.0"
    }

    buildTypes {
        debug { applicationIdSuffix = ".debug"; versionNameSuffix = "-debug" }
        release {
            isMinifyEnabled = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation(project(":core"))
    implementation(project(":launcher"))
    implementation(project(":settings"))
    implementation(project(":systemui"))
    implementation("androidx.work:work-runtime-ktx:2.9.1")
}
