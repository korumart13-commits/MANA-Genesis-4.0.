package com.mana.os.ai

import android.content.Context
import android.os.BatteryManager
import android.os.PowerManager
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.mana.os.core.ai.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

class ManaLearningWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {
    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        val app = applicationContext
        val prefs = app.getSharedPreferences("mana_ai_settings", Context.MODE_PRIVATE)
        if (!prefs.getBoolean("learning_enabled", true)) return@withContext Result.success()
        val key = ApiKeyVault(app).read()
        if (key.isNullOrBlank()) {
            LearningReportStore(app).save(emptyReport(LearningState.PAUSED_USER), "Не настроен Brave Search API key")
            return@withContext Result.success()
        }
        val battery = app.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        val percent = battery.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY).coerceIn(0, 100)
        val power = app.getSystemService(Context.POWER_SERVICE) as PowerManager
        val charging = true // WorkManager starts this worker only while charging.
        val thermalOk = android.os.Build.VERSION.SDK_INT < 29 || power.currentThermalStatus < PowerManager.THERMAL_STATUS_SEVERE
        val snapshot = ResourceSnapshot(percent, charging, unmeteredNetwork = true,
            deviceIdle = power.isDeviceIdleMode, thermalHeadroomOk = thermalOk, userEnabled = true)
        val store = AtomicFileKnowledgeStore(File(app.filesDir, "mana_ai/knowledge.bin"))
        val domains = MANAResearchCatalog.approvedHosts
        val engine = AdaptiveIntelligenceEngine(
            search = BraveSearchProvider(key),
            fetcher = SafeHttpsDocumentFetcher(DomainAllowlist(domains)),
            evaluator = ConservativeEvidenceEvaluator(MANAResearchCatalog.officialHosts,
                MANAResearchCatalog.academicHosts, MANAResearchCatalog.standardsHosts),
            store = store, allowlist = DomainAllowlist(domains),
            policy = LearningPolicy(minBatteryPercent = 35, maxTopicsPerCycle = 3,
                maxDocumentsPerTopic = 5, maxDocumentChars = 20_000, maxBytesPerCycle = 1_000_000L,
                minIndependentSources = 2)
        )
        try {
            val report = engine.learn(MANAResearchCatalog.starterTopics, snapshot)
            LearningReportStore(app).save(report)
            Result.success()
        } catch (e: Exception) {
            LearningReportStore(app).save(emptyReport(LearningState.READY), "Ошибка цикла: ${e.javaClass.simpleName}: ${e.message.orEmpty().take(180)}")
            Result.retry()
        }
    }

    private fun emptyReport(state: LearningState) = LearningCycleReport(
        System.currentTimeMillis(), System.currentTimeMillis(), 0, 0, 0, 0, 0, 0, state, emptyList())
}
