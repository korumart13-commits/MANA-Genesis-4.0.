package com.mana.os.ai

import android.app.Activity
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import androidx.work.WorkManager
import com.mana.os.core.MANA

class ManaAiReportsActivity : Activity() {
    private lateinit var report: TextView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(22, 28, 22, 22); setBackgroundColor(android.graphics.Color.parseColor(MANA.Colors.BACKGROUND)) }
        root.addView(TextView(this).apply { text = "MANA ADAPTIVE INTELLIGENCE"; textSize = 21f; gravity = Gravity.CENTER; setTextColor(android.graphics.Color.parseColor(MANA.Colors.ACCENT)) })
        val key = EditText(this).apply { hint = "Brave Search API key"; setSingleLine(true); inputType = 129; setTextColor(android.graphics.Color.WHITE); setHintTextColor(0xff91a9c5.toInt()) }
        root.addView(key, ViewGroup.LayoutParams(-1, -2))
        root.addView(Button(this).apply { text = "Сохранить API-ключ"; setOnClickListener { try { ApiKeyVault(this@ManaAiReportsActivity).save(key.text.toString().trim()); key.setText(""); toast("Ключ сохранён в Android Keystore") } catch (e: Exception) { toast("Не удалось сохранить ключ: ${e.message}") } } })
        root.addView(Button(this).apply { text = "Удалить сохранённый API-ключ"; setOnClickListener { ApiKeyVault(this@ManaAiReportsActivity).clear(); toast("Ключ удалён") } })
        root.addView(Button(this).apply { text = "Запустить обучение сейчас"; setOnClickListener { ManaLearningScheduler.runNow(this@ManaAiReportsActivity); toast("Задание добавлено в очередь Android") } })
        root.addView(Button(this).apply { text = "Обновить отчёты"; setOnClickListener { refresh() } })
        root.addView(Button(this).apply { text = "Остановить фоновое обучение"; setOnClickListener { getSharedPreferences("mana_ai_settings", MODE_PRIVATE).edit().putBoolean("learning_enabled", false).apply(); ManaLearningScheduler.cancel(this@ManaAiReportsActivity); toast("Фоновое обучение остановлено") } })
        root.addView(Button(this).apply { text = "Возобновить фоновое обучение"; setOnClickListener { getSharedPreferences("mana_ai_settings", MODE_PRIVATE).edit().putBoolean("learning_enabled", true).apply(); ManaLearningScheduler.register(this@ManaAiReportsActivity); toast("Фоновое обучение зарегистрировано") } })
        report = TextView(this).apply { textSize = 13f; setTextColor(android.graphics.Color.parseColor(MANA.Colors.TEXT)); setPadding(0, 18, 0, 18) }
        val scroll = ScrollView(this).apply { addView(report) }
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root); refresh()
    }
    private fun refresh() { report.text = LearningReportStore(this).latestText() }
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
}
