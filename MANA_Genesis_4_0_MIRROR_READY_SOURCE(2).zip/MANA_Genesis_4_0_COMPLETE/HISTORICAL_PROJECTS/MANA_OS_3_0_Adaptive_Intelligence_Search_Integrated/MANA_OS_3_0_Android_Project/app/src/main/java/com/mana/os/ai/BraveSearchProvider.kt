package com.mana.os.ai

import com.mana.os.core.ai.SearchHit
import com.mana.os.core.ai.WebSearchProvider
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URLEncoder
import java.net.URL

/** Official Brave Web Search API adapter. The key is supplied at runtime, never compiled in. */
class BraveSearchProvider(private val apiKey: String) : WebSearchProvider {
    override fun search(query: String, limit: Int): List<SearchHit> {
        require(apiKey.isNotBlank()) { "Brave API key is not configured" }
        val encoded = URLEncoder.encode(query.take(500), "UTF-8")
        val url = URL("https://api.search.brave.com/res/v1/web/search?q=$encoded&count=${limit.coerceIn(1, 10)}&country=US&search_lang=en")
        val connection = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 10_000
            readTimeout = 12_000
            setRequestProperty("Accept", "application/json")
            setRequestProperty("X-Subscription-Token", apiKey)
        }
        try {
            val code = connection.responseCode
            if (code == 429) throw IllegalStateException("Brave API: превышен лимит запросов (429)")
            if (code !in 200..299) throw IllegalStateException("Brave API вернул HTTP $code")
            val body = connection.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText().take(1_000_000) }
            val results = JSONObject(body).optJSONObject("web")?.optJSONArray("results") ?: return emptyList()
            return (0 until results.length()).mapNotNull { i ->
                val item = results.optJSONObject(i) ?: return@mapNotNull null
                val title = item.optString("title").take(500)
                val link = item.optString("url")
                val snippet = item.optString("description").take(2_000)
                if (title.isBlank() || link.isBlank()) null else SearchHit(title, link, snippet)
            }
        } finally { connection.disconnect() }
    }
}
