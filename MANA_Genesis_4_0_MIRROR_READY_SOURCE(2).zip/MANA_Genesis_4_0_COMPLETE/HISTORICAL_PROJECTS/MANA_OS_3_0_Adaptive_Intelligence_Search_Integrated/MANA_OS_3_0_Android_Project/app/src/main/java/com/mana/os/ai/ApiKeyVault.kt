package com.mana.os.ai

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/** Encrypts the provider key at rest with an Android Keystore AES-GCM key. */
class ApiKeyVault(context: Context) {
    private val prefs = context.getSharedPreferences("mana_ai_secrets", Context.MODE_PRIVATE)
    private val alias = "mana.adaptive.brave.aes.v1"

    fun save(value: String) {
        require(value.isNotBlank() && value.length < 512)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, getOrCreateKey())
        val encrypted = cipher.doFinal(value.toByteArray(Charsets.UTF_8))
        val packed = cipher.iv + encrypted
        check(prefs.edit().putString("brave_key", Base64.encodeToString(packed, Base64.NO_WRAP)).commit())
    }

    fun read(): String? {
        return try {
        val packed = prefs.getString("brave_key", null)?.let { Base64.decode(it, Base64.NO_WRAP) } ?: return null
        if (packed.size <= 12) return null
        val iv = packed.copyOfRange(0, 12)
        val data = packed.copyOfRange(12, packed.size)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, getOrCreateKey(), GCMParameterSpec(128, iv))
        cipher.doFinal(data).toString(Charsets.UTF_8)
        } catch (_: Exception) { null }
    }

    fun clear() { prefs.edit().remove("brave_key").apply() }

    private fun getOrCreateKey(): SecretKey {
        val store = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (store.getKey(alias, null) as? SecretKey)?.let { return it }
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        generator.init(KeyGenParameterSpec.Builder(alias, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setRandomizedEncryptionRequired(true)
            .build())
        return generator.generateKey()
    }
}
