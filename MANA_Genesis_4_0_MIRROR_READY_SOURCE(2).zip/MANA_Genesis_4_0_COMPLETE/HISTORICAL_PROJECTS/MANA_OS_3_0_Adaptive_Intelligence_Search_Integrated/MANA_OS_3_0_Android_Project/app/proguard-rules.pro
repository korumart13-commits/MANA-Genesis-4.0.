# MANA OS release-specific keep rules go here.
