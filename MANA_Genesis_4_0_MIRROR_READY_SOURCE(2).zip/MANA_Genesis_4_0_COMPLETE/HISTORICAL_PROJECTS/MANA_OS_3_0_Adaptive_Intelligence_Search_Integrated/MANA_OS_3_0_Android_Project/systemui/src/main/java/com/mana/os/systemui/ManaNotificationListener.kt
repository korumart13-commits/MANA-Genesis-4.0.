package com.mana.os.systemui

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import com.mana.os.core.ManaNotification
import com.mana.os.core.ManaNotificationRepository

/**
 * Receives notifications only after the device owner explicitly enables
 * Notification Access in Android Settings. This is NOT an AOSP SystemUI replacement.
 */
class ManaNotificationListener : NotificationListenerService() {
    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val extras = sbn.notification.extras
        val title = extras.getCharSequence("android.title")?.toString().orEmpty()
        val text = extras.getCharSequence("android.text")?.toString().orEmpty()
        if (title.isNotBlank() || text.isNotBlank()) {
            ManaNotificationRepository.add(
                ManaNotification(
                    title = title.ifBlank { sbn.packageName },
                    message = text,
                    timestamp = sbn.postTime,
                    packageName = sbn.packageName
                )
            )
        }
    }
}
