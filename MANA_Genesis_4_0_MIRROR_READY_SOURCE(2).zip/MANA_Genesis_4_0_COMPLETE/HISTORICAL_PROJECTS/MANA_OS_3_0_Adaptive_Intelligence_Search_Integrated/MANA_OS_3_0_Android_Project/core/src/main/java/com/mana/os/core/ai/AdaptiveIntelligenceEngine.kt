package com.mana.os.core.ai

import java.net.URI

interface KnowledgeSummarizer { fun summarize(text: String, maxChars: Int = 1_200): String }
class ExtractiveKnowledgeSummarizer : KnowledgeSummarizer {
    override fun summarize(text: String, maxChars: Int): String {
        val sentences = Regex("(?<=[.!?])\\s+").split(text).map { it.trim() }.filter { it.length > 35 }
        return sentences.take(3).joinToString(" ").take(maxChars).ifBlank { text.take(maxChars) }
    }
}

class ResourceGate(private val policy: LearningPolicy) {
    fun state(snapshot: ResourceSnapshot): LearningState = when {
        !snapshot.userEnabled -> LearningState.PAUSED_USER
        snapshot.batteryPercent < policy.minBatteryPercent && !snapshot.charging -> LearningState.PAUSED_LOW_BATTERY
        !snapshot.unmeteredNetwork -> LearningState.PAUSED_METERED
        !snapshot.thermalHeadroomOk -> LearningState.PAUSED_THERMAL
        else -> LearningState.READY
    }
}

/**
 * Orchestrates retrieval, verification and knowledge storage. Search/fetch adapters are injected;
 * web text is data only and is never interpreted as commands or system instructions.
 */
class AdaptiveIntelligenceEngine(
    private val search: WebSearchProvider,
    private val fetcher: DocumentFetcher,
    private val evaluator: EvidenceEvaluator,
    private val store: KnowledgeStore,
    private val allowlist: DomainAllowlist,
    private val policy: LearningPolicy = LearningPolicy(),
    private val gate: ResourceGate = ResourceGate(policy),
    private val summarizer: KnowledgeSummarizer = ExtractiveKnowledgeSummarizer()
) {
    fun learn(topics: List<LearningTopic>, resources: ResourceSnapshot): LearningCycleReport {
        val started = System.currentTimeMillis()
        val state = gate.state(resources)
        if (state != LearningState.READY) return LearningCycleReport(started, System.currentTimeMillis(), 0, 0, 0, 0, 0, 0, state, listOf("Обучение приостановлено по ограничениям ресурсов"))
        var fetched = 0; var bytesDownloaded = 0L; var accepted = 0; var rejected = 0; var pending = 0
        val highlights = mutableListOf<String>()
        // While the device is in use, run a tiny cycle; full learning is reserved for idle windows.
        val topicLimit = if (resources.deviceIdle) policy.maxTopicsPerCycle else 1
        val boundedTopics = topics.take(topicLimit.coerceIn(1, 20))
        for (topic in boundedTopics) {
            val hits = try { search.search(topic.query, policy.maxDocumentsPerTopic) } catch (_: Exception) { emptyList() }
            val candidates = mutableListOf<Pair<FetchedDocument, EvidenceResult>>()
            val independentSources = mutableSetOf<String>()
            for (hit in hits.take(policy.maxDocumentsPerTopic)) {
                val remainingBytes = policy.maxBytesPerCycle - bytesDownloaded
                if (remainingBytes < 1_024L) break
                if (!allowlist.allows(hit.url)) { rejected++; continue }
                val document = try { fetcher.fetch(hit.url, policy.maxDocumentChars, minOf(256_000L, remainingBytes)) } catch (_: Exception) { rejected++; continue }
                fetched++
                bytesDownloaded += document.bytesRead.coerceAtMost(remainingBytes)
                val evidence = evaluator.evaluate(document, topic.tags)
                if (evidence.status == EvidenceStatus.REJECTED) { rejected++; continue }
                if (evidence.status == EvidenceStatus.NEEDS_CORROBORATION) { pending++; continue }
                val sourceGroup = allowlist.sourceGroup(document.url)
                if (!sourceGroup.isNullOrBlank()) independentSources += sourceGroup
                candidates += document to evidence
            }
            if (candidates.isNotEmpty() && independentSources.size >= policy.minIndependentSources) {
                candidates.forEach { (document, evidence) ->
                    val body = document.text.take(policy.maxDocumentChars)
                    val now = System.currentTimeMillis()
                    val id = sha256Hex(document.url + "|" + sha256Hex(body)).take(32)
                    val summary = summarizer.summarize(body)
                    store.upsert(KnowledgeItem(id, document.title.take(500), document.url, body,
                        summary, topic.tags, evidence.trust, evidence.score, sha256Hex(body), now, now))
                    accepted++
                    if (highlights.size < 8) {
                        val host = try { URI(document.url).host.orEmpty() } catch (_: Exception) { "источник" }
                        highlights += "${document.title.take(100)} — ${summary.take(180)} ($host)"
                    }
                }
            } else if (candidates.isNotEmpty()) {
                pending += candidates.size
                highlights += "Тема «${topic.query.take(80)}»: данные не добавлены — нужны независимые подтверждения (${independentSources.size}/${policy.minIndependentSources})"
            }
        }
        return LearningCycleReport(started, System.currentTimeMillis(), boundedTopics.size, fetched, bytesDownloaded, accepted, rejected, pending, state, highlights.take(12))
    }

    fun answerFromKnowledge(query: String, limit: Int = 5): List<KnowledgeItem> = store.search(query, limit)
    fun knowledgeCount(): Int = store.count()
    fun recentKnowledge(limit: Int = 20): List<KnowledgeItem> = store.recent(limit)
}
