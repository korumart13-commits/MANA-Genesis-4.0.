package com.mana.os.core.ai

import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.File
import java.io.FileOutputStream
import java.nio.file.Files
import java.nio.file.StandardCopyOption
import java.util.concurrent.locks.ReentrantReadWriteLock
import kotlin.concurrent.read
import kotlin.concurrent.write

interface KnowledgeStore {
    fun upsert(item: KnowledgeItem)
    fun search(query: String, limit: Int = 20): List<KnowledgeItem>
    fun recent(limit: Int = 30): List<KnowledgeItem>
    fun count(): Int
}

/** Atomic local store for public knowledge only. Do not put personal data or secrets here. */
class AtomicFileKnowledgeStore(private val file: File, private val maxItems: Int = 5_000) : KnowledgeStore {
    private val lock = ReentrantReadWriteLock()
    private val magic = 0x4D414E43

    override fun upsert(item: KnowledgeItem) = lock.write {
        require(item.body.length <= 24_000 && item.title.length <= 500)
        val all = readAll().associateBy { it.id }.toMutableMap()
        all[item.id] = item
        writeAll(all.values.sortedByDescending { it.lastVerifiedAt }.take(maxItems))
    }

    override fun search(query: String, limit: Int): List<KnowledgeItem> = lock.read {
        val terms = query.lowercase().split(Regex("\\W+")).filter { it.length > 2 }.toSet()
        readAll().map { item ->
            val hay = (item.title + " " + item.summary + " " + item.body + " " + item.tags.joinToString(" ")).lowercase()
            item to terms.count { hay.contains(it) }
        }.filter { it.second > 0 }.sortedWith(compareByDescending<Pair<KnowledgeItem, Int>> { it.second }
            .thenByDescending { it.first.evidenceScore }).take(limit.coerceIn(1, 100)).map { it.first }
    }

    override fun recent(limit: Int): List<KnowledgeItem> = lock.read {
        readAll().sortedByDescending { it.collectedAt }.take(limit.coerceIn(1, 100))
    }
    override fun count(): Int = lock.read { readAll().size }

    private fun readAll(): List<KnowledgeItem> {
        if (!file.exists()) return emptyList()
        return try {
            DataInputStream(file.inputStream().buffered()).use { input ->
                require(input.readInt() == magic)
                val count = input.readInt().coerceIn(0, maxItems)
                List(count) {
                    val id = readText(input, 1_024); val title = readText(input, 4_096); val url = readText(input, 8_192)
                    val body = readText(input, 100_000); val summary = readText(input, 12_000)
                    val tags = readText(input, 4_096).split('|').filter { it.isNotBlank() }.toSet()
                    val trust = SourceTrust.valueOf(readText(input, 128)); val score = input.readInt()
                    val hash = readText(input, 256); val collected = input.readLong(); val verified = input.readLong()
                    KnowledgeItem(id, title, url, body, summary, tags, trust, score, hash, collected, verified)
                }
            }
        } catch (_: Exception) { emptyList() }
    }

    private fun writeAll(items: List<KnowledgeItem>) {
        file.parentFile?.mkdirs()
        val temp = File(file.parentFile, file.name + ".tmp")
        FileOutputStream(temp).use { stream ->
            val out = DataOutputStream(stream.buffered())
            out.writeInt(magic); out.writeInt(items.size)
            items.forEach { item ->
                writeText(out, item.id, 200); writeText(out, item.title, 500); writeText(out, item.canonicalUrl, 2_000)
                writeText(out, item.body, 24_000); writeText(out, item.summary, 2_000); writeText(out, item.tags.joinToString("|"), 1_000)
                writeText(out, item.trust.name, 32); out.writeInt(item.evidenceScore); writeText(out, item.sha256, 128)
                out.writeLong(item.collectedAt); out.writeLong(item.lastVerifiedAt)
            }
            out.flush()
            stream.fd.sync()
        }
        try {
            Files.move(temp.toPath(), file.toPath(), StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE)
        } catch (_: java.nio.file.AtomicMoveNotSupportedException) {
            Files.move(temp.toPath(), file.toPath(), StandardCopyOption.REPLACE_EXISTING)
        }
    }

    private fun writeText(out: DataOutputStream, value: String, maxChars: Int) {
        val bytes = value.take(maxChars).toByteArray(Charsets.UTF_8)
        out.writeInt(bytes.size)
        out.write(bytes)
    }

    private fun readText(input: DataInputStream, maxBytes: Int): String {
        val size = input.readInt()
        require(size in 0..maxBytes) { "Invalid knowledge record field size" }
        val bytes = ByteArray(size)
        input.readFully(bytes)
        return bytes.toString(Charsets.UTF_8)
    }

}
