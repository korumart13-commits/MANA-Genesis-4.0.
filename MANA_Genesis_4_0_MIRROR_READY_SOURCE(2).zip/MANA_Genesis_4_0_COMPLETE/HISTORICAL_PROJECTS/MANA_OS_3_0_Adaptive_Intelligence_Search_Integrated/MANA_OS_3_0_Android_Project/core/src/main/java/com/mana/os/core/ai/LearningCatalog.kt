package com.mana.os.core.ai

/** Starter research domains. Search providers may return only URLs admitted by this policy. */
object MANAResearchCatalog {
    val approvedHosts = setOf(
        "developer.android.com", "source.android.com", "android.com",
        "kotlinlang.org", "docs.oracle.com", "nist.gov", "cisa.gov",
        "ietf.org", "arxiv.org", "w3.org"
    )
    val officialHosts = setOf("developer.android.com", "source.android.com", "android.com", "kotlinlang.org", "docs.oracle.com")
    val standardsHosts = setOf("nist.gov", "cisa.gov", "ietf.org", "w3.org")
    val academicHosts = setOf("arxiv.org")

    val starterTopics = listOf(
        LearningTopic("android", "Android platform architecture and APIs", setOf("android", "aosp", "platform")),
        LearningTopic("kotlin", "Kotlin language and Android development", setOf("kotlin", "programming")),
        LearningTopic("security", "Mobile operating system security engineering", setOf("security", "mobile")),
        LearningTopic("privacy", "Privacy engineering and data minimization", setOf("privacy", "security")),
        LearningTopic("ai", "Machine learning evaluation and model safety", setOf("ai", "machine-learning")),
        LearningTopic("networking", "Internet protocols and network reliability", setOf("networking", "standards")),
        LearningTopic("science", "General science discoveries and research literacy", setOf("science", "research")),
        LearningTopic("mathematics", "Mathematics, statistics and logical reasoning", setOf("math", "statistics")),
        LearningTopic("engineering", "Electrical, mechanical and software engineering", setOf("engineering")),
        LearningTopic("languages", "Language learning, linguistics and translation", setOf("languages", "linguistics")),
        LearningTopic("history", "World history and primary historical sources", setOf("history", "humanities")),
        LearningTopic("accessibility", "Digital accessibility and assistive technology", setOf("accessibility", "ux")),
        LearningTopic("productivity", "Knowledge management and personal productivity methods", setOf("productivity", "planning"))
    )
}
