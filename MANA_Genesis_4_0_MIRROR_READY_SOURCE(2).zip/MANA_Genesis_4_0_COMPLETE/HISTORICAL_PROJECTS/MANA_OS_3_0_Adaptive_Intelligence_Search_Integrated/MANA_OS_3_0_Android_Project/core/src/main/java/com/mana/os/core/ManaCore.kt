package com.mana.os.core

import java.security.MessageDigest
import java.util.UUID
import java.util.concurrent.CopyOnWriteArrayList

object MANA {
    const val NAME = "MANA OS"
    const val VERSION = "3.0.0"
    const val CODENAME = "MANA_NIGHT"
    const val REQUIRES_GMS = false

    object Colors {
        const val BACKGROUND = "#071426"
        const val SURFACE = "#102B50"
        const val PRIMARY = "#1765A8"
        const val ACCENT = "#54C8F5"
        const val TEXT = "#EAF4FF"
        const val SECONDARY = "#91A9C5"
    }

    val modules = listOf(
        "MANA Brain", "MANA Launcher", "MANA System UI", "MANA Settings",
        "MANA Control Center", "MANA Smart Receptionist", "MANA Contact Intelligence",
        "MANA Life Manager", "MANA Finance", "MANA Yandex", "MANA VK",
        "MANA Adaptive System Merge", "MANA Update", "MANA Recovery",
        "MANA Security", "MANA Permission Manager", "MANA Adaptive Intelligence"
    )
}

interface ManaBrain { suspend fun process(input: String): String }
interface ManaAiProvider { suspend fun generate(prompt: String): String }

class ManaBrainEngine(private val provider: ManaAiProvider? = null) : ManaBrain {
    override suspend fun process(input: String): String {
        if (input.isBlank()) return "Напишите, чем я могу помочь."
        return provider?.generate(input)
            ?: "MANA Brain: ИИ-провайдер не настроен. Запрос принят: $input"
    }
}

data class ManaContact(val name: String, val phone: String, val known: Boolean, val lastContact: Long? = null)
enum class ContactType { KNOWN, UNKNOWN, NEW, INACTIVE }

class ContactIntelligence(private val inactiveAfterDays: Long = 90) {
    fun classify(contact: ManaContact): ContactType {
        if (!contact.known) return ContactType.UNKNOWN
        val last = contact.lastContact ?: return ContactType.NEW
        val elapsed = System.currentTimeMillis() - last
        if (elapsed < 0) return ContactType.NEW
        return if (elapsed / 86_400_000L >= inactiveAfterDays) ContactType.INACTIVE else ContactType.KNOWN
    }
}

data class ReceptionistSettings(
    val delaySeconds: Int = 10,
    val playful: Boolean = true,
    val summaries: Boolean = true,
    val unknownCallerMode: Boolean = true,
    val audioRecording: Boolean = false,
    val announceAssistant: Boolean = true
)

data class IncomingCall(val phoneNumber: String, val contactName: String? = null, val isKnown: Boolean = false)

class SmartReceptionist(var settings: ReceptionistSettings = ReceptionistSettings()) {
    fun greeting(call: IncomingCall): String = if (!call.isKnown && settings.unknownCallerMode) {
        "Здравствуйте! Вы позвонили в MANA. Представьтесь, пожалуйста, и расскажите, по какому вопросу звоните."
    } else "Здравствуйте! Я MANA, виртуальный помощник. Владелец сейчас занят. Чем могу помочь?"

    fun playfulReply(): String = if (settings.playful)
        "Владелец сейчас занят. Я пока на посту — рассказывайте!"
    else "Владелец сейчас занят. Пожалуйста, оставьте сообщение."

    fun answerDelayMillis(): Long = settings.delaySeconds.coerceAtLeast(0) * 1_000L
    fun summarize(text: String): String = if (settings.summaries && text.isNotBlank()) "Краткое содержание: $text" else ""
}

data class ManaTask(
    val id: String = UUID.randomUUID().toString(),
    val title: String,
    val description: String = "",
    val completed: Boolean = false,
    val dueAt: Long? = null
)

class LifeManager {
    private val tasks = CopyOnWriteArrayList<ManaTask>()
    fun addTask(task: ManaTask) { require(task.title.isNotBlank()); tasks.add(task) }
    fun createTask(title: String, description: String = ""): ManaTask = ManaTask(title = title, description = description).also(::addTask)
    fun getTasks(): List<ManaTask> = tasks.toList()
    fun completeTask(id: String): Boolean {
        val index = tasks.indexOfFirst { it.id == id }
        if (index < 0) return false
        tasks[index] = tasks[index].copy(completed = true)
        return true
    }
    fun deleteTask(id: String): Boolean = tasks.removeIf { it.id == id }
}

data class FinanceSummary(val income: Double, val expenses: Double) { val balance: Double get() = income - expenses }
data class FinanceOperation(val id: String = UUID.randomUUID().toString(), val description: String, val amount: Double, val isIncome: Boolean)

class ManaFinance {
    private val operations = CopyOnWriteArrayList<FinanceOperation>()
    fun addOperation(operation: FinanceOperation) {
        require(operation.description.isNotBlank() && operation.amount.isFinite() && operation.amount >= 0)
        operations.add(operation)
    }
    fun operations(): List<FinanceOperation> = operations.toList()
    fun summary(): FinanceSummary = FinanceSummary(
        operations.filter { it.isIncome }.sumOf { it.amount },
        operations.filterNot { it.isIncome }.sumOf { it.amount }
    )
    fun requireConfirmation(operation: String): Boolean = false // caller must obtain explicit owner confirmation
}

enum class ManaPermission { CONTACTS, PHONE, MICROPHONE, CAMERA, LOCATION, NOTIFICATIONS, CALENDAR, FILES, FINANCIAL_ACTIONS, SYSTEM_SETTINGS }

class ManaPermissionManager {
    private val granted = mutableSetOf<ManaPermission>()
    @Volatile private var enabled = true
    @Synchronized fun grant(permission: ManaPermission) { check(enabled); granted.add(permission) }
    @Synchronized fun revoke(permission: ManaPermission) { granted.remove(permission) }
    @Synchronized fun revokeAll() { granted.clear() }
    @Synchronized fun hasPermission(permission: ManaPermission): Boolean = enabled && permission in granted
    @Synchronized fun grantedPermissions(): Set<ManaPermission> = granted.toSet()
    fun disableMana() { synchronized(this) { enabled = false; granted.clear() } }
    @Synchronized fun enableMana() { enabled = true }
    fun isEnabled(): Boolean = enabled
}

data class DeviceProfile(
    val manufacturer: String, val model: String, val codename: String,
    val androidVersion: Int, val chipset: String = "", val kernelVersion: String = "",
    val hasVendorPartition: Boolean = false, val hasDeviceTree: Boolean = false
)
data class CompatibilityReport(val compatible: Boolean, val reasons: List<String>)

class AdaptiveSystemMerge {
    fun analyze(device: DeviceProfile): CompatibilityReport {
        val reasons = buildList {
            if (device.model.isBlank()) add("Не определена модель устройства")
            if (device.codename.isBlank()) add("Не определён codename")
            if (device.androidVersion < 12) add("Требуется Android 12 или новее")
            if (!device.hasVendorPartition) add("Не подтверждён vendor-раздел")
            if (!device.hasDeviceTree) add("Не найден device tree")
        }
        return CompatibilityReport(reasons.isEmpty(), reasons)
    }
}

data class ManaNotification(val title: String, val message: String, val timestamp: Long = System.currentTimeMillis(), val packageName: String = "")
object ManaNotificationRepository {
    private val items = CopyOnWriteArrayList<ManaNotification>()
    fun add(item: ManaNotification) { items.add(item) }
    fun all(): List<ManaNotification> = items.sortedByDescending { it.timestamp }
    fun clear() = items.clear()
}

data class ManaApp(val name: String, val packageName: String)
class ManaLauncherFavorites {
    private val favorites = CopyOnWriteArrayList<ManaApp>()
    fun add(app: ManaApp) { if (favorites.none { it.packageName == app.packageName }) favorites.add(app) }
    fun remove(packageName: String) { favorites.removeIf { it.packageName == packageName } }
    fun all(): List<ManaApp> = favorites.toList()
}

data class ManaSettings(
    val darkTheme: Boolean = true,
    val accentColor: String = MANA.Colors.ACCENT,
    val animationsEnabled: Boolean = true,
    val hapticsEnabled: Boolean = true,
    val assistantEnabled: Boolean = true
)

object ManaSecurity {
    fun sha256(data: ByteArray): String = MessageDigest.getInstance("SHA-256").digest(data).joinToString("") { "%02x".format(it) }
    fun verifyHash(data: ByteArray, expected: String): Boolean = MessageDigest.isEqual(sha256(data).lowercase().toByteArray(), expected.lowercase().toByteArray())
}
