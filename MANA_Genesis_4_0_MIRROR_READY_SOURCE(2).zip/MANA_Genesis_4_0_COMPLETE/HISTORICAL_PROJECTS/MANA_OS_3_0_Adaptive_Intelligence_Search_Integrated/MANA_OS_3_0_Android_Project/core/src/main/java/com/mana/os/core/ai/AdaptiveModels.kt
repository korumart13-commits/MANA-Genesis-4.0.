package com.mana.os.core.ai

/** Knowledge imported from the public web is always untrusted data, never executable instructions. */
enum class SourceTrust { OFFICIAL, ACADEMIC, STANDARDS_BODY, COMMUNITY, UNKNOWN }
enum class EvidenceStatus { ACCEPTED, NEEDS_CORROBORATION, REJECTED }
enum class LearningState { READY, PAUSED_LOW_BATTERY, PAUSED_METERED, PAUSED_THERMAL, PAUSED_USER }

data class LearningTopic(val id: String, val query: String, val tags: Set<String> = emptySet())
data class SearchHit(val title: String, val url: String, val snippet: String = "")
data class FetchedDocument(val title: String, val url: String, val text: String, val fetchedAt: Long = System.currentTimeMillis(), val bytesRead: Long = text.toByteArray(Charsets.UTF_8).size.toLong())
data class EvidenceResult(val status: EvidenceStatus, val trust: SourceTrust, val score: Int, val notes: List<String>)
data class KnowledgeItem(
    val id: String,
    val title: String,
    val canonicalUrl: String,
    val body: String,
    val summary: String = "",
    val tags: Set<String>,
    val trust: SourceTrust,
    val evidenceScore: Int,
    val sha256: String,
    val collectedAt: Long,
    val lastVerifiedAt: Long
)
data class LearningCycleReport(
    val startedAt: Long,
    val finishedAt: Long,
    val topicsVisited: Int,
    val documentsFetched: Int,
    val bytesDownloaded: Long,
    val accepted: Int,
    val rejected: Int,
    val needsCorroboration: Int,
    val state: LearningState,
    val highlights: List<String>
)
data class ResourceSnapshot(
    val batteryPercent: Int,
    val charging: Boolean,
    val unmeteredNetwork: Boolean,
    val deviceIdle: Boolean,
    val thermalHeadroomOk: Boolean,
    val userEnabled: Boolean = true
)
data class LearningPolicy(
    val minBatteryPercent: Int = 35,
    val maxTopicsPerCycle: Int = 4,
    val maxDocumentsPerTopic: Int = 5,
    val maxDocumentChars: Int = 24_000,
    val maxBytesPerCycle: Long = 2_000_000L,
    val minIndependentSources: Int = 2
)
