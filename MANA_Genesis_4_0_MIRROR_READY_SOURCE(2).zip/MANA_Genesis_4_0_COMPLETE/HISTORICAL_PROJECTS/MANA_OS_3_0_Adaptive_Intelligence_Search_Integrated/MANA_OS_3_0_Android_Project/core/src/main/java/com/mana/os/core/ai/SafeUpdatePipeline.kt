package com.mana.os.core.ai

import java.io.File
import java.security.Signature
import java.security.spec.X509EncodedKeySpec
import java.security.KeyFactory
import java.util.Base64
import java.security.MessageDigest

// Updates are staged only. Activation is delegated to the signed MANA Update/A-B rollback system.
enum class ArtifactKind { MODEL, DECLARATIVE_RULES, ALGORITHM_PLUGIN }
enum class UpdateStatus { REJECTED, STAGED_FOR_TESTS, READY_FOR_OS_UPDATE }
data class UpdateManifest(
    val id: String, val versionCode: Long, val kind: ArtifactKind, val sha256: String,
    val signatureBase64: String, val minOsVersion: String, val maxBytes: Long
) {
    /** Canonical bytes covered by the publisher signature. */
    fun canonicalPayload(): ByteArray = listOf(id, versionCode.toString(), kind.name, sha256.lowercase(), minOsVersion, maxBytes.toString())
        .joinToString("\n").toByteArray(Charsets.UTF_8)
}
data class UpdateDecision(val status: UpdateStatus, val reason: String)
interface ArtifactCompatibilityCheck { fun compatible(manifest: UpdateManifest): Boolean }
interface ArtifactSandboxTest { fun passes(file: File, kind: ArtifactKind): Boolean }

class RsaManifestSignatureVerifier(private val x509PublicKeyBase64: String) {
    fun verify(payload: ByteArray, signatureBase64: String): Boolean = try {
        val keyBytes = Base64.getDecoder().decode(x509PublicKeyBase64)
        val key = KeyFactory.getInstance("RSA").generatePublic(X509EncodedKeySpec(keyBytes))
        Signature.getInstance("SHA256withRSA").run {
            initVerify(key); update(payload); verify(Base64.getDecoder().decode(signatureBase64))
        }
    } catch (_: Exception) { false }
}

class SafeUpdatePipeline(
    private val verifier: RsaManifestSignatureVerifier,
    private val compatibility: ArtifactCompatibilityCheck,
    private val sandbox: ArtifactSandboxTest,
    private val stagingDirectory: File
) {
    fun stage(file: File, manifest: UpdateManifest, currentVersionCode: Long): UpdateDecision {
        if (!file.isFile || manifest.maxBytes !in 1..(500L * 1024 * 1024) || file.length() !in 1..manifest.maxBytes)
            return UpdateDecision(UpdateStatus.REJECTED, "Файл отсутствует или превышает допустимый размер")
        if (manifest.versionCode <= currentVersionCode)
            return UpdateDecision(UpdateStatus.REJECTED, "Откат версии или повторная установка запрещены")
        if (!compatibility.compatible(manifest))
            return UpdateDecision(UpdateStatus.REJECTED, "Артефакт несовместим с этой сборкой MANA OS")
        stagingDirectory.mkdirs()
        val staged = File(stagingDirectory, "${manifest.id}.candidate")
        val temp = File(stagingDirectory, "${manifest.id}.download.tmp")
        return try {
            file.inputStream().use { input -> temp.outputStream().use { output -> input.copyTo(output) } }
            if (temp.length() !in 1..manifest.maxBytes || sha256File(temp) != manifest.sha256.lowercase()) {
                temp.delete()
                return UpdateDecision(UpdateStatus.REJECTED, "Размер или SHA-256 не совпадает с манифестом")
            }
            if (!verifier.verify(manifest.canonicalPayload(), manifest.signatureBase64)) {
                temp.delete()
                return UpdateDecision(UpdateStatus.REJECTED, "Подпись издателя недействительна")
            }
            if (!sandbox.passes(temp, manifest.kind)) {
                temp.delete()
                return UpdateDecision(UpdateStatus.REJECTED, "Изолированные тесты не пройдены")
            }
            java.nio.file.Files.move(temp.toPath(), staged.toPath(), java.nio.file.StandardCopyOption.REPLACE_EXISTING)
            UpdateDecision(UpdateStatus.STAGED_FOR_TESTS, "Проверенный кандидат сохранён. Активация не выполнялась; передать в MANA Update для A/B-установки и отката.")
        } catch (e: Exception) {
            temp.delete()
            UpdateDecision(UpdateStatus.REJECTED, "Ошибка безопасной подготовки: ${e.javaClass.simpleName}")
        }
    }
}

private fun sha256File(file: File): String {
    val digest = MessageDigest.getInstance("SHA-256")
    file.inputStream().buffered().use { input ->
        val buffer = ByteArray(64 * 1024)
        while (true) { val n = input.read(buffer); if (n < 0) break; digest.update(buffer, 0, n) }
    }
    return digest.digest().joinToString("") { "%02x".format(it) }
}
