package com.mana.os.launcher

import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import com.mana.os.core.MANA

class ManaLauncherActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(24, 40, 24, 24)
            setBackgroundColor(android.graphics.Color.parseColor(MANA.Colors.BACKGROUND))
        }
        root.addView(TextView(this).apply {
            text = "MANA"
            textSize = 34f
            gravity = Gravity.CENTER
            setTextColor(android.graphics.Color.parseColor(MANA.Colors.ACCENT))
        }, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        root.addView(TextView(this).apply {
            text = "Ваше пространство. Ваш контроль."
            textSize = 14f
            gravity = Gravity.CENTER
            setTextColor(android.graphics.Color.parseColor(MANA.Colors.SECONDARY))
        })

        val pm = packageManager
        val launcherIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(launcherIntent, PackageManager.MATCH_DEFAULT_ONLY)
            .distinctBy { it.activityInfo.packageName }
            .sortedBy { it.loadLabel(pm).toString().lowercase() }

        apps.forEach { info ->
            val label = info.loadLabel(pm).toString()
            val packageName = info.activityInfo.packageName
            root.addView(TextView(this).apply {
                text = "◈  $label"
                textSize = 17f
                setTextColor(android.graphics.Color.parseColor(MANA.Colors.TEXT))
                setPadding(12, 14, 12, 14)
                isClickable = true
                setOnClickListener {
                    val launch = pm.getLaunchIntentForPackage(packageName)
                    if (launch != null) startActivity(launch)
                }
            }, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        }
        setContentView(root)
    }
}
