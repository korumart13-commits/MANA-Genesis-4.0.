# Проверяемый статус исходников

- Проект разбит на 5 Gradle-модулей.
- Реализованы базовые Kotlin-классы ядра, простая HOME Activity, экран настроек и NotificationListenerService.
- В коде нет фиктивного успешного OAuth-подключения или фиктивной установки OTA.
- SystemUI в этом проекте НЕ заменён.
- Сборка не запускалась в этой среде: Android SDK/Gradle build environment не подтверждены. Откройте проект в Android Studio и выполните Gradle Sync/assembleDebug.
