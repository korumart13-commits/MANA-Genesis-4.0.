package com.mana.os.settings

import android.app.Activity
import android.os.Bundle
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.Switch
import android.widget.TextView
import com.mana.os.core.MANA
import com.mana.os.core.ManaSettings

object ManaSettingsStore {
    @Volatile var current = ManaSettings()
}

class ManaSettingsActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 36, 24, 24)
            setBackgroundColor(android.graphics.Color.parseColor(MANA.Colors.BACKGROUND))
        }
        root.addView(TextView(this).apply {
            text = "Настройки MANA"
            textSize = 26f
            setTextColor(android.graphics.Color.parseColor(MANA.Colors.ACCENT))
        })
        val dark = Switch(this).apply {
            text = "Тёмная тема"
            setTextColor(android.graphics.Color.parseColor(MANA.Colors.TEXT))
            isChecked = ManaSettingsStore.current.darkTheme
            setOnCheckedChangeListener { _, checked ->
                ManaSettingsStore.current = ManaSettingsStore.current.copy(darkTheme = checked)
            }
        }
        root.addView(dark)
        val animations = Switch(this).apply {
            text = "Анимации"
            setTextColor(android.graphics.Color.parseColor(MANA.Colors.TEXT))
            isChecked = ManaSettingsStore.current.animationsEnabled
            setOnCheckedChangeListener { _, checked ->
                ManaSettingsStore.current = ManaSettingsStore.current.copy(animationsEnabled = checked)
            }
        }
        root.addView(animations)
        val assistant = Switch(this).apply {
            text = "MANA Assistant"
            setTextColor(android.graphics.Color.parseColor(MANA.Colors.TEXT))
            isChecked = ManaSettingsStore.current.assistantEnabled
            setOnCheckedChangeListener { _, checked ->
                ManaSettingsStore.current = ManaSettingsStore.current.copy(assistantEnabled = checked)
            }
        }
        root.addView(assistant)
        root.addView(TextView(this).apply {
            text = "Настройки хранятся в памяти процесса в этой базовой версии. Постоянное хранение и системные настройки AOSP подключаются отдельно."
            textSize = 13f
            setPadding(0, 24, 0, 0)
            setTextColor(android.graphics.Color.parseColor(MANA.Colors.SECONDARY))
        })
        setContentView(root)
    }
}
