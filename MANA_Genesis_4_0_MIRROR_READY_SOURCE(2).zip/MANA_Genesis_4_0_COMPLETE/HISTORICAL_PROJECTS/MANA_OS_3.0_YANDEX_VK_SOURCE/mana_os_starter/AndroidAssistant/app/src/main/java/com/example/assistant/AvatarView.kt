package com.example.assistant

import android.content.Context
import android.graphics.Canvas
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.util.AttributeSet
import android.view.MotionEvent
import android.widget.ImageView
import kotlin.math.sin

/**
 * Девочка-аватар: «дышит», качается и кивает, когда ассистент говорит,
 * и следит за пальцем, если коснуться её. Рамка с закруглёнными углами неподвижна,
 * двигается только картинка внутри неё.
 */
class AvatarView @JvmOverloads constructor(ctx: Context, attrs: AttributeSet? = null) :
    ImageView(ctx, attrs), Runnable {

    private val density = resources.displayMetrics.density
    private val clip = Path()
    private val border = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 1.5f * density; color = 0x59FFFFFF
    }
    private val t0 = System.nanoTime()
    private var running = false
    private var wantTalk = false
    private var talking = 0f          // 0..1, плавно включается и выключается
    private var beatEnv = 0f          // затухающий кивок
    private var lookX = 0f
    private var lookY = 0f            // текущий взгляд
    private var targetX = 0f
    private var targetY = 0f          // куда указывает палец

    init {
        setImageResource(R.drawable.avatar)
        scaleType = ScaleType.MATRIX
    }

    /** Включить или выключить «разговорную» анимацию. */
    fun talk(on: Boolean) { wantTalk = on }

    /** Короткий кивок (на каждое слово). */
    fun beat() { beatEnv = 1f }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        clip.reset()
        clip.addRoundRect(RectF(0f, 0f, w.toFloat(), h.toFloat()), 24 * density, 24 * density, Path.Direction.CW)
        val d = drawable
        if (d != null && d.intrinsicWidth > 0) {
            // Вписываем весь портрет: не обрезаем ноги и верх головы.
            val k = minOf(w / d.intrinsicWidth.toFloat(), h / d.intrinsicHeight.toFloat())
            imageMatrix = Matrix().apply {
                setScale(k, k)
                postTranslate((w - d.intrinsicWidth * k) / 2f, (h - d.intrinsicHeight * k) / 2f)
            }
        }
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val sec = (System.nanoTime() - t0) / 1e9
        val breathe = 1f + 0.008f * sin(sec * 2 * Math.PI / 4.0).toFloat()
        val sway = 1.3f * talking * sin(sec * 2 * Math.PI / 0.65).toFloat()
        c.save()
        c.clipPath(clip)
        c.translate(lookX * 8 * density, lookY * 5 * density - beatEnv * 5 * density)
        c.rotate(sway + lookX * 2f, w / 2f, h)
        c.scale(1f, breathe, w / 2f, h)
        super.onDraw(c)
        c.restore()
        c.drawPath(clip, border)
    }

    override fun run() {
        if (!running) return
        lookX += (targetX - lookX) * 0.18f
        lookY += (targetY - lookY) * 0.18f
        talking += ((if (wantTalk) 1f else 0f) - talking) * 0.1f
        beatEnv *= 0.88f
        invalidate()
        postOnAnimation(this)
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        running = true
        postOnAnimation(this)
    }

    override fun onDetachedFromWindow() {
        running = false
        removeCallbacks(this)
        super.onDetachedFromWindow()
    }

    // Не крутим анимацию, пока приложение свёрнуто
    override fun onWindowVisibilityChanged(v: Int) {
        super.onWindowVisibilityChanged(v)
        if (v == VISIBLE) {
            if (!running && isAttachedToWindow) { running = true; postOnAnimation(this) }
        } else running = false
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                targetX = ((e.x / width) * 2f - 1f).coerceIn(-1f, 1f)
                targetY = ((e.y / height) * 2f - 1f).coerceIn(-1f, 1f)
            }
            MotionEvent.ACTION_UP -> { targetX = 0f; targetY = 0f; performClick() }
            MotionEvent.ACTION_CANCEL -> { targetX = 0f; targetY = 0f }
        }
        return true
    }

    override fun performClick(): Boolean {
        super.performClick()
        beat()
        return true
    }
}
