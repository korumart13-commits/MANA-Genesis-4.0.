package com.example.assistant

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.GridLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import android.content.pm.ResolveInfo

/** MANA home shell: a selectable Android HOME launcher, not a replacement firmware. */
class ManaHomeActivity : Activity() {
    private val bg = 0xFF10111B.toInt()
    private val panel = 0xFF1B1D2B.toInt()
    private val accent = 0xFF9B82FF.toInt()
    private lateinit var appGrid: GridLayout
    private lateinit var search: EditText
    private var allApps: List<ResolveInfo> = emptyList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        window.decorView.systemUiVisibility = 0

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(22), dp(18), dp(14))
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR,
                intArrayOf(0xFF10111B.toInt(), 0xFF242039.toInt(), 0xFF111522.toInt()))
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(content)

        content.addView(label("MANA", 32f, Color.WHITE, true).apply { letterSpacing = .12f })
        content.addView(label("ТВОЯ ИНТЕЛЛЕКТУАЛЬНАЯ СРЕДА", 10f, 0xFFB7B2CE.toInt(), true))
        content.addView(space(18))

        search = EditText(this).apply {
            hint = "Найти приложение или выполнить поиск"
            setHintTextColor(0xFFAAA6BC.toInt())
            setTextColor(Color.WHITE)
            textSize = 15f
            singleLine = true
            imeOptions = EditorInfo.IME_ACTION_SEARCH
            setPadding(dp(16), dp(13), dp(16), dp(13))
            background = rounded(panel, dp(18))
            setOnEditorActionListener { _, action, _ ->
                if (action == EditorInfo.IME_ACTION_SEARCH) { doSearch(text.toString()); true } else false
            }
        }
        content.addView(search, matchWrap())
        content.addView(space(16))

        val hero = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(18))
            background = rounded(0xFF29243E.toInt(), dp(20))
        }
        hero.addView(label("Привет. Я Мана.", 22f, Color.WHITE, true))
        hero.addView(label("Твой помощник, голосовой интерфейс и центр управления.", 13f, 0xFFD0CBE0.toInt()))
        hero.addView(space(12))
        hero.addView(action("Открыть диалог с Маной") {
            startActivity(Intent(this, MainActivity::class.java))
        })
        content.addView(hero, matchWrap())
        content.addView(space(16))

        content.addView(label("СЕРВИСЫ", 11f, 0xFFB7B2CE.toInt(), true))
        val serviceRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        serviceRow.addView(serviceCard("Яндекс", "Поиск и сервисы") {
            openService(listOf("ru.yandex.searchplugin", "com.yandex.browser"), "https://ya.ru")
        }, LinearLayout.LayoutParams(0, dp(100), 1f))
        serviceRow.addView(spaceHorizontal(10))
        serviceRow.addView(serviceCard("VK", "Сообщества и общение") {
            openService(listOf("com.vkontakte.android"), "https://vk.com")
        }, LinearLayout.LayoutParams(0, dp(100), 1f))
        content.addView(serviceRow)
        content.addView(space(18))

        content.addView(label("ПРИЛОЖЕНИЯ", 11f, 0xFFB7B2CE.toInt(), true))
        content.addView(space(8))
        appGrid = GridLayout(this).apply { columnCount = 3; useDefaultMargins = false }
        content.addView(appGrid, matchWrap())
        content.addView(space(12))
        content.addView(action("Обновить список приложений") { loadApps() })
        content.addView(space(8))
        content.addView(action("Настройки MANA") {
            startActivity(Intent(this, SettingsActivity::class.java))
        })
        content.addView(space(20))
        content.addView(label("MANA работает поверх Android. Сервисы Яндекса и VK открываются через установленные приложения или официальные сайты. Это интеграция, а не заявление о принадлежности MANA этим компаниям.", 11f, 0xFFAAA6BC.toInt()))

        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        loadApps()
    }

    override fun onResume() { super.onResume(); if (::appGrid.isInitialized) loadApps() }

    private fun loadApps() {
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        allApps = packageManager.queryIntentActivities(intent, 0)
            .filter { it.activityInfo.packageName != packageName }
            .sortedBy { it.loadLabel(packageManager).toString().lowercase() }
        appGrid.removeAllViews()
        allApps.forEach { info ->
            val tile = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                setPadding(dp(5), dp(10), dp(5), dp(10))
                background = rounded(0x331FFFFFFF, dp(14))
                isClickable = true
                isFocusable = true
                setOnClickListener { launch(info) }
            }
            val icon = ImageView(this).apply {
                setImageDrawable(info.loadIcon(packageManager))
                scaleType = ImageView.ScaleType.FIT_CENTER
            }
            tile.addView(icon, LinearLayout.LayoutParams(dp(38), dp(38)))
            tile.addView(label(info.loadLabel(packageManager).toString(), 11f, Color.WHITE, true).apply {
                gravity = Gravity.CENTER
                maxLines = 2
            })
            val lp = GridLayout.LayoutParams().apply {
                width = 0; height = dp(88); columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
                setMargins(dp(3), dp(3), dp(3), dp(3))
            }
            appGrid.addView(tile, lp)
        }
        if (allApps.isEmpty()) appGrid.addView(label("Не удалось получить список приложений.", 13f, Color.WHITE))
    }

    private fun launch(info: ResolveInfo) {
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            .setClassName(info.activityInfo.packageName, info.activityInfo.name)
        try { startActivity(i) } catch (_: Exception) { toast("Не удалось открыть приложение") }
    }

    private fun doSearch(raw: String) {
        val q = raw.trim()
        if (q.isEmpty()) return
        val match = allApps.firstOrNull { it.loadLabel(packageManager).toString().contains(q, true) }
        if (match != null) launch(match) else openUrl("https://ya.ru/search/?text=${Uri.encode(q)}")
    }

    private fun openService(packages: List<String>, url: String) {
        for (pkg in packages) {
            val launch = packageManager.getLaunchIntentForPackage(pkg)
            if (launch != null) { try { startActivity(launch); return } catch (_: Exception) {} }
        }
        openUrl(url)
    }

    private fun openUrl(url: String) {
        try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }
        catch (_: Exception) { toast("Нет приложения для открытия ссылки") }
    }

    private fun action(text: String, run: () -> Unit) = TextView(this).apply {
        this.text = text; setTextColor(Color.WHITE); textSize = 14f; gravity = Gravity.CENTER
        setPadding(dp(14), dp(13), dp(14), dp(13)); background = rounded(accent, dp(15))
        isClickable = true; isFocusable = true; setOnClickListener { run() }
    }

    private fun serviceCard(title: String, subtitle: String, run: () -> Unit) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_VERTICAL
        setPadding(dp(14), dp(12), dp(14), dp(12)); background = rounded(panel, dp(17))
        addView(label(title, 18f, Color.WHITE, true)); addView(label(subtitle, 11f, 0xFFB7B2CE.toInt()))
        isClickable = true; isFocusable = true; setOnClickListener { run() }
    }

    private fun label(text: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        this.text = text; textSize = size; setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }
    private fun rounded(color: Int, radius: Int) = GradientDrawable().apply {
        setColor(color); cornerRadius = radius.toFloat()
    }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun matchWrap() = LinearLayout.LayoutParams(-1, -2)
    private fun space(h: Int) = View(this).apply { layoutParams = LinearLayout.LayoutParams(1, dp(h)) }
    private fun spaceHorizontal(w: Int) = View(this).apply { layoutParams = LinearLayout.LayoutParams(dp(w), 1) }
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}
