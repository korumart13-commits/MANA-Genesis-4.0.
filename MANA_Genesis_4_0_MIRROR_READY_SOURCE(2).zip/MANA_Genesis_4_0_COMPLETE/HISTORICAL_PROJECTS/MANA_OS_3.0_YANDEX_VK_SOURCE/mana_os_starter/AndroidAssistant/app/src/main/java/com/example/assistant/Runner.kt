package com.example.assistant

import android.content.Context

/** Общие настройки. */
object Cfg {
    const val NAME = "Мана"
    fun name(c: Context): String = c.getSharedPreferences("cfg", Context.MODE_PRIVATE).getString("name", NAME) ?: NAME
}

/** Выполнение команды: сначала встроенные команды, потом (если есть ключ) Claude. Вызывать из фонового потока. */
object Runner {
    fun run(ctx: Context, cmd: String, say: (String) -> Unit, stop: () -> Unit) {
        val sp = ctx.getSharedPreferences("cfg", Context.MODE_PRIVATE)
        val key = sp.getString("key", "") ?: ""
        val name = Cfg.name(ctx)
        try {
            val r = Local.handle(ctx, cmd, name, key.isNotBlank())
            if (!r.unknown) {
                if (r.stopSpeech) stop()
                if (r.say.isNotBlank()) say(r.say)
                for (a in r.actions) {
                    val svc = AssistantService.instance
                    if (svc == null) say("Сначала включите доступ к управлению: кнопка «1» на экране.")
                    else svc.act(a)?.let { say(it) }
                }
                return
            }
            ask(ctx, cmd, key, name, say)
        } catch (e: Exception) { say("Ошибка: ${e.message}") }
    }

    private fun ask(ctx: Context, cmd: String, key: String, name: String, say: (String) -> Unit) {
        var input = cmd
        repeat(6) {
            val svc = AssistantService.instance
            val r = Brain.ask(key, input, svc?.screenText() ?: "служба не включена", Memory.all(ctx), name)
            r.optString("say").takeIf { it.isNotBlank() }?.let { say(it) }
            r.optJSONArray("remember")?.let { for (i in 0 until it.length()) Memory.add(ctx, it.getString(i)) }
            val acts = r.optJSONArray("actions")
            if (acts != null && svc != null)
                for (i in 0 until acts.length()) { svc.act(acts.getJSONObject(i))?.let { say(it) }; Thread.sleep(1200) }
            if (r.optBoolean("done", true)) return
            input = "Продолжай выполнение команды: $cmd"
        }
    }
}
