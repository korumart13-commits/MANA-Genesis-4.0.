package com.example.assistant

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var tts: TextToSpeech
    private lateinit var avatar: AvatarView
    private lateinit var chat: LinearLayout
    private lateinit var scroll: ScrollView
    private lateinit var input: EditText
    private lateinit var nameView: TextView

    private var pending = 0          // сколько фраз сейчас в очереди озвучки
    private var utt = 0

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        window.statusBarColor = getColor(R.color.bg_top)
        window.navigationBarColor = getColor(R.color.bg_bottom)
        setContentView(R.layout.activity_main)
        avatar = findViewById(R.id.avatarView)
        chat = findViewById(R.id.chatList)
        input = findViewById(R.id.inputView)
        nameView = findViewById(R.id.assistantNameView)
        scroll = chat.parent as ScrollView

        findViewById<View>(R.id.sendButton).setOnClickListener { send() }
        findViewById<View>(R.id.micButton).setOnClickListener { startVoice() }
        findViewById<View>(R.id.settingsButton).setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }

        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts.language = Locale("ru")
                // Мягкая, немного более спокойная подача; доступные голоса зависят от TTS-движка Android.
                tts.setSpeechRate(0.92f)
                tts.setPitch(1.04f)
                tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) { runOnUiThread { avatar.talk(true) } }
                    override fun onDone(utteranceId: String?) { speechFinished() }
                    override fun onError(utteranceId: String?) { speechFinished() }
                    // на каждое слово девочка «кивает» в такт речи
                    override fun onRangeStart(utteranceId: String?, start: Int, end: Int, frame: Int) {
                        runOnUiThread { avatar.beat() }
                    }
                })
            }
        }

        addBubble("Привет! Я ${Cfg.name(this)}. Спроси меня о чём-нибудь или скажи «что ты умеешь».", false)

        // Запуск как системный помощник (долгое нажатие Home / кнопки питания): сразу слушаем
        val assist = intent?.action == Intent.ACTION_ASSIST || intent?.getBooleanExtra("assist", false) == true
        if (s == null && assist) window.decorView.post { startVoice() }
    }

    override fun onResume() {
        super.onResume()
        nameView.text = Cfg.name(this)
    }

    override fun onDestroy() {
        tts.shutdown()
        super.onDestroy()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    // ---------- чат ----------
    private fun addBubble(text: String, mine: Boolean) {
        val tv = TextView(this).apply {
            setText(text)
            setTextColor(Color.WHITE)
            textSize = 15f
            setBackgroundResource(if (mine) R.drawable.bubble_user else R.drawable.bubble_ai)
            setPadding(dp(14), dp(9), dp(14), dp(9))
            maxWidth = (resources.displayMetrics.widthPixels * 0.78f).toInt()
        }
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            gravity = if (mine) Gravity.END else Gravity.START
            topMargin = dp(6)
        }
        chat.addView(tv, lp)
        scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
    }

    private fun send() {
        val t = input.text.toString().trim()
        if (t.isEmpty()) return
        input.setText("")
        run(t)
    }

    // ---------- голос ----------
    private fun startVoice() {
        try {
            startActivityForResult(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ru-RU") }, 1)
        } catch (e: Exception) {
            addBubble("На телефоне нет службы распознавания речи. Введите команду текстом.", false)
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 1 && resultCode == RESULT_OK) {
            data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()?.let { run(it) }
        }
    }

    private fun speechFinished() = runOnUiThread {
        pending = maxOf(0, pending - 1)
        if (pending == 0) avatar.talk(false)
    }

    private fun say(t: String) = runOnUiThread {
        addBubble(t, false)
        pending++
        if (tts.speak(t, TextToSpeech.QUEUE_ADD, null, "u${utt++}") != TextToSpeech.SUCCESS) pending--
    }

    private fun run(cmd: String) {
        if (cmd.isBlank()) return
        addBubble(cmd, true)
        Thread {
            Runner.run(this, cmd, { say(it) }, { runOnUiThread { tts.stop(); pending = 0; avatar.talk(false) } })
        }.start()
    }
}
