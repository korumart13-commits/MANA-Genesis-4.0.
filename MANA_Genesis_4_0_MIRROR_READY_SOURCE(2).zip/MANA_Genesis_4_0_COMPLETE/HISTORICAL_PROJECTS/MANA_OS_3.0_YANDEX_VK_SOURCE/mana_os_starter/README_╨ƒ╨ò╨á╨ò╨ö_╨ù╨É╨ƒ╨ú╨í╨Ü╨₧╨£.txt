MANA OS — STARTER PROJECT

Это ZIP с исходным Android-проектом MANA, а не APK и не прошивка.

Для открытия нужен Android Studio или совместимая среда сборки Android. На Android-телефоне можно распаковать архив и открыть проект в мобильной среде разработки, если она поддерживает Gradle и Android SDK. Сам архив напрямую установить нельзя.

Внутри:
- AndroidAssistant/ — объединённый исходный проект;
- AndroidAssistant/MANA_OS_ROADMAP_RU.md — план перехода к MANA OS.

Сборка APK (при наличии Java 17 и Android SDK API 34):
  cd AndroidAssistant
  ./gradlew assembleDebug

APK появится в app/build/outputs/apk/debug/app-debug.apk, если сборка пройдёт.

Ограничения: проект не может тайно захватывать устройство или обходить Android. Полноценная MANA OS потребует отдельной AOSP-прошивки под точную модель телефона и проверенных драйверов.
