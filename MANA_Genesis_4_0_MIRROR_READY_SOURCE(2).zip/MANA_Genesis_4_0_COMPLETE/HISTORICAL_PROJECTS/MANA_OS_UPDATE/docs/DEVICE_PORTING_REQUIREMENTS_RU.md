# Требования к поддержке нового устройства

Для каждого устройства создаётся отдельный каталог `payload/devices/<codename>/`.

Обязательные данные:
- manufacturer, model, product, device codename, SoC;
- поддерживаемая версия Android и базовый build fingerprint;
- схема разделов и размеры/слоты A/B или Virtual A/B;
- bootloader/recovery compatibility;
- kernel, dtbo, vendor_boot, vbmeta и system/product/system_ext/vendor образы — только если они нужны данной платформе;
- AVB descriptors, signing certificate/key id, OTA metadata и rollback index;
- SHA-256 каждого payload-файла;
- инструкции восстановления и проверенный путь возврата на штатную прошивку.

Установщик обязан сверить все идентификаторы до записи. При любом несовпадении — остановиться без изменения разделов. Нельзя обходить Verified Boot, отключать SELinux или подменять vendor blobs от другой модели.

## Принцип сохранения MANA
Оригинальные исходники остаются в `source/` без изменений. Системные компоненты MANA должны добавляться отдельными APK/модулями в AOSP build по мере их фактической реализации; отсутствие исходника или API нельзя маскировать фиктивной заглушкой.
